@extends('layouts.app')
@section('title', 'Registration')
@section('register')
<!-- breadcrumb start  -->
    <div class="breadcrumb-areablack">
        <div class="container">
            <div class="row">
                <div class="col-md-12"></div>
            </div>
        </div>
    </div>
    <!-- breadcrumb end  -->
    

    <!-- article area start  -->
    <div class="article-area margin-top-50">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="section-title-02 margin-bottom-30 text-center">
                        <h3>YOUR ARTDEAL ACCOUNT</h3>
                        <h6>Please fill in the following details to create an account</h6>
                    </div>
                </div>
            </div>
         </div>
    </div>
    <!-- article area end  -->
    
    <!-- contact form start  -->
    @if(session()->has('message'))
        <div class="alert alert-success">
            {{ session()->get('message') }}
        </div>
    @endif
    <div class="contact-form text-center padding-top-80 padding-bottom-80">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <form action="{{ route('register')}}" method="post">
                    	{{ csrf_field() }}
                        <div class="form-row">
                          <div class="form-group col-md-6">
                            <input type="text" class="form-control" name="name" placeholder="Name*" value="{{ session('auto', '') }}" required>
                          </div>
                          <div class="form-group col-md-6">
                            <input type="email" class="form-control" name="email" placeholder="Email (This will be Your Username)*" required>
                            @if($errors->has('email'))
                            <div style="width: 100%" class="alert alert-danger alert-dismissible fade show" role="alert">{{ $errors->first('email') }}
                               <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                               <span aria-hidden="true">&times;</span>
                               </button>
                            </div>
                            @endif
                          </div>
                        </div>
                        @if($errors->has('password'))
                        <div style="width: 100%" class="alert alert-danger alert-dismissible fade show" role="alert">{{ $errors->first('password') }}
                           <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                           <span aria-hidden="true">&times;</span>
                           </button>
                        </div>
                        @endif
                        <div class="form-row">
                          <div class="form-group col-md-6">
                            <input type="text" class="form-control" name="password" placeholder="Password*" required>
                          </div>
                          <div class="form-group col-md-6">
                            <input type="text" class="form-control" name="cpassword" placeholder="Confirm Password*" required>
                          </div>
                        </div>
                        
                        
                        <div class="form-row">
                          <div class="form-group col-md-6">
                            <input type="number" class="form-control" name="mobile" placeholder="Mobile Number*" required>
                            @if($errors->has('mobile'))
                            <div style="width: 100%" class="alert alert-danger alert-dismissible fade show" role="alert">{{ $errors->first('mobile') }}
                               <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                               <span aria-hidden="true">&times;</span>
                               </button>
                            </div>
                            @endif
                          </div>
                          <div class="form-group col-md-6">
                            <input type="text" class="form-control" name="country" placeholder="Country*" required>
                          </div>
                          </div>
                        
                        <div class="form-row">
                          <div class="form-group col-md-6">
                            <input type="text" class="form-control" name="house_address" placeholder="Flat No. / House No. / Building Name*" required>
                          </div>
                          <div class="form-group col-md-6">
                            <input type="text" class="form-control" name="street_area_address" placeholder="Street Name / Area Name*" required> 
                          </div>
                        </div>
                        
                        <div class="form-row">
                          <div class="form-group col-md-6">
                            <input type="text" class="form-control" name="state" placeholder="State*" required>
                          </div>
                        </div>
                        
                        <div class="form-row">
                          <div class="form-group col-md-6">
                            <input type="text" class="form-control" name="city" placeholder="City*" required>
                          </div>
                          <div class="form-group col-md-6">
                            <input type="text" class="form-control" name="pincode" placeholder="Postal Code*" required>
                          </div>
                        </div>
                        
                        
                        <button type="submit" class="btn btn-contact">SUBMIT</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <!-- contact form end  -->
@endsection