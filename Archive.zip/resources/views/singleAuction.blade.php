@extends('layouts.app')
@section('title', 'ArtDeal')
@section('singleAuction')
<!-- breadcrumb start  -->
    <div class="breadcrumb-area">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="breadcrumb-inner d-flex justify-content-between">
                        <h2 class="page-title">Online Auction of Arts & Collectibles</h2>
                        <ul class="page-list">
                            <li><a href="index.html">Download Catalogue</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- breadcrumb end  -->
    
    @if(count($data) >= 1)
    <!-- about content start  -->
    <div class="about-content margin-top-50">
        <div class="container">
            <div class="row">
                <div class="col-lg-5">
                    <div class="content-left">
                        <h5><b>{{ date_format(date_create($data[0]->start_date),"d M") }} - 
	                        {{ date_format(date_create($data[0]->end_date),"d M Y") }} </b>
	                    </h5>
                        {!!$data[0]->art_description!!}
                    </div>
                </div>
                <div class="col-lg-7">
                    <div class="thumb">
                        <img height="500" width="670" src="public/images/bigimage/{{$data[0]->big_image}}" alt="">
                        </div>
                </div>
            </div>
        </div>
    </div>
    <!-- about content end  -->
    
    
    <!-- artwork area start  -->
    <div class="tranding-area margin-top-20">
        <div class="container">
           <div class="tab-content">
                <div class="tab-pane fade in show active" id="one">
                    <div class="row">
                    	@for($i=0;$i<count(json_decode($data[0]->images));$i++)
                        <div class="col-lg-4 col-md-6 col-sm-6 col-12">
                            <div class="product-style-02 margin-top-40">
                                <div class="thumb">
                                    <a href="live-auction-blowup.html"><img src="public/images/auctionDetails/{{(json_decode($data[0]->images))[$i]}}" alt=""></a>
                                    <span class="new">LOT 1</span>
                                    </div>
                                <div class="article-style-p">
			                        <div class="content">
			                            <h3><a href="#">{{ ucfirst($data[0]->title)}}</a></h3>
			                            <p>{{ $data[0]->year}}</p>
			                            <h6>₹ {{ $data[0]->price_start}} - ₹ {{ $data[0]->price_upto}}</h6>
			                            <div class="btn-wrapper">
			                                <a href="live-auction-blowup.html" class="btn-bid btn-white">PLACE BID <i class="icon-arrow-buttom"></i></a>
			                            </div>
			                        </div>
			                    </div>
                            </div>
                        </div>
                        @endfor
                        
                    </div>
                </div>
             </div>
        </div>
    </div>
    @else
    <h3 style="text-align: center;padding: 20px;">Art details not Added.</h3>
    @endif
    <!-- artwork area end  -->
@endsection