@extends('dashboard.layouts.app')
@section('title', 'Add Sliders')
@section('allSliders')
	<!-- Page Heading -->
                    <div class="form-row">
                        <div class="col"><h1 class="h3 mb-2 text-gray-800">All Slider</h1></div>
                    <div class="col1"><a href="{{ route('addSlider') }}" class="btn btn-primary btn-icon-split">
                            <span class="text">Add Slider</span></a></div>
							</div>
                    
                    <!-- <p class="mb-4">DataTables is a third party plugin that is used to generate the demo table below.
                        For more information about DataTables, please visit the <a target="_blank"
                            href="https://datatables.net">official DataTables documentation</a>.</p>
 -->
                    <!-- DataTales Example -->
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <!-- <h6 class="m-0 font-weight-bold text-primary">DataTables Example</h6> -->
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">

                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th width="18%">Slider Name</th>
                                            
                                            <th width="18%">Date</th>
                                            <th width="14%">Button Name</th>
                                            
                                            <th width="12%">Image</th>
                                            
                                            <th width="20%">Action</th>
                                        </tr>
                                    </thead>
                                    
                                    <tbody>
                                    	@foreach($data as $datas)
                                        <tr>
                                            <td>{{ ucfirst($datas->name) }} </td>
                                            
                                            <td>{{ $datas->created_at }}</td>
                                            <td>{{ $datas->button_name }}</td>
                                            
                                            <td>{{ $datas->image }}</td>
                                            
                                            
                                            <td align="center"><a href="#">Edit</a> | <a href="#">Delete</td>
                                        </tr>
                                        @endforeach
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
@endsection