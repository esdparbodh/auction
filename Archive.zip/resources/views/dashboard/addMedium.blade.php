@extends('dashboard.layouts.app')
@section('title', 'Add Medium')
@section('addMedium')
<!-- Page Heading -->
                    
                        <h1 class="h3 mb-2 text-gray-800">Add Medium</h1>
                    <!-- DataTales Example -->
                    @if(session()->has('message'))
				        <div class="alert alert-success">
				            {{ session()->get('message') }}
				        </div>
				    @endif
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <!-- <h6 class="m-0 font-weight-bold text-primary">DataTables Example</h6> -->
                        </div>
                        <div class="card-body">
                            
                            <form action="{{ Request::is('addMediums') ? route('addMedium') : route('editMedium') }}" method="post">
                                {{ csrf_field() }}
                                <input type="hidden" name="id" value="{{ Request::is('addMediums') ? '' : $data[0]->id }}">
                            <div class="form-row">
                              <div class="col">
							  <label>Enter Title</label>
                                <input type="text" class="form-control" id="title" placeholder="Enter Title" name="title" value="{{ Request::is('addMediums') ? '' : $data[0]->title }}">
                              </div>
                            </div>
							<br>
                               <!--  <label>Description</label>
                                <textarea name="editor1" >{!! Request::is('addMediums') ? '' : $data[0]->description !!}</textarea>
                            <br> -->
                            <div>
                                <button type="submit" class="btn btn-primary" >{{ Request::is('addMediums') ? 'Add Medium' : 'Update Medium' }}</button>
                            </div>
                            
                          </form>
                        </div>
                    </div>
@endsection