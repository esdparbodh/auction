@extends('dashboard.layouts.app')
@section('title', 'Add Art')
@section('allArts')
	<!-- Page Heading -->
                    <div class="form-row">
                        <div class="col"><h1 class="h3 mb-2 text-gray-800">All Arts</h1></div>
                    <div class="col1"><a href="{{ route('auctionDetails')}}" class="btn btn-primary btn-icon-split">
                            <span class="text">Add Art</span></a></div>
							</div>
                    
                    <!-- <p class="mb-4">DataTables is a third party plugin that is used to generate the demo table below.
                        For more information about DataTables, please visit the <a target="_blank"
                            href="https://datatables.net">official DataTables documentation</a>.</p>
 -->
                    <!-- DataTales Example -->
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <!-- <h6 class="m-0 font-weight-bold text-primary">DataTables Example</h6> -->
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">

                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th width="18%">Title</th>
                                            <th width="14%">Department</th>
                                            <th width="13%">
				                                <select class="form-control">
				                                    <option>Select </option>
				                                    <option>All</option>
													<option>Live</option>
				                                    <option>Upcoming</option>
				                                    <option>Past</option>
				                                </select> </th>
                                            
                                            <th width="14%">Auction</th>
                                            <th width="14%">Upload</th>
                                            
                                            <th width="12%">Created At </th>
                                            
                                            <th width="20%">Action</th>
                                        </tr>
                                    </thead>
                                    
                                    <tbody>
                                    	@foreach($data as $datas)
                                        <tr>
                                            <td>{{ ucfirst($datas->title) }} </td>
                                            <td>{{ $datas->department }}</td>
                                            <td>{{ $datas->art_type }}</td>
                                            <td>{{ $datas->auction }}</td>
                                            <td>
                                                @if($datas->images == null && $datas->big_image == null && $datas->b1 == null && $datas->b2 == null && $datas->b3 == null && $datas->b4 == null)
                                                <a href="{{ url('uploadArtImages')}}.{{$datas->id}}">Upload Images</a>
                                                @else
                                                <a href="{{ url('uploadArtImages')}}.{{$datas->id}}">Update Images</a>
                                                @endif
                                            </td>
                                            <td>{{ $datas->created_at }}</td>
                                            <td align="center"><a href="#">Edit</a> | <a href="#">Delete</td>
                                        </tr>
                                        @endforeach
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
@endsection