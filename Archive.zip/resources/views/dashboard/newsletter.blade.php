@extends('dashboard.layouts.app')
@section('title', 'Newsletter')
@section('newsletter')
<!-- Page Heading -->
                    
                        <h1 class="h3 mb-2 text-gray-800">All Newsletter Subscribers</h1>
                    
                    <!-- <p class="mb-4">DataTables is a third party plugin that is used to generate the demo table below.
                        For more information about DataTables, please visit the <a target="_blank"
                            href="https://datatables.net">official DataTables documentation</a>.</p>
 -->
                    <!-- DataTales Example -->
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <!-- <h6 class="m-0 font-weight-bold text-primary">DataTables Example</h6> -->
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">

                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th>Name</th>
                                            <th>Email</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    
                                    <tbody>
                                        @if(sizeof($data)>0)
                                    	@foreach($data as $datas)
                                        <tr>
                                            <td>{{ ucfirst($datas->name) }}</td>
                                            <td>{{ $datas->email }}</td>
                                            @if($datas->status_id == 1) 
                                        	<td><a href="{{ url('unsubscribe')}}.{{$datas->id}}">Unsubscribe</a></td>
                                        	@endif
                                            
                                        </tr>
                                        @endforeach
                                        @endif
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
@endsection