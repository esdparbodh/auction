 @extends('dashboard.layouts.app')
@section('title', 'Add Auction')
@section('addAuction')
	<!-- Page Heading -->
                    
                        <h1 class="h3 mb-2 text-gray-800">Add New Auction</h1>
                   
                    
                    <!-- <p class="mb-4">DataTables is a third party plugin that is used to generate the demo table below.
                        For more information about DataTables, please visit the <a target="_blank"
                            href="https://datatables.net">official DataTables documentation</a>.</p>
 -->
                    <!-- DataTales Example -->
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <!-- <h6 class="m-0 font-weight-bold text-primary">DataTables Example</h6> -->
                        </div>
                        <div class="card-body">
                            @if(session()->has('message'))
            						        <div class="alert alert-success">
            						            {{ session()->get('message') }}
            						        </div>
            						    @endif
                            <form action="{{ Request::is('addAuction') ? route('addAuction') : route('editAuction') }}" method="post" enctype="multipart/form-data">
                            	{{ csrf_field() }}
                              <div class="form-row">
                                <div class="col">
                                  <label>Department</label>
                                  <select class="form-control" name="department">
                                    <option>Select </option>
                                    @foreach($data as $datas)
                                      <option value="{{ $datas->title}}">{{ $datas->title}}</option>
                                      @endforeach
                                  </select>
                                </div>
                                <div class="col">
                                <label>Enter Title</label>
                                <input type="text" class="form-control" name="title" required >
                              </div>

                              </div>
							               <div class="form-row">
                              <div class="col">
                                <label>Auction Type</label>
                                <select class="form-control" name="type" required>
	                                <option value="" selected>Select </option>
									                 <option value="Live">Live</option>
	                                <option value="Upcoming">Upcoming</option>
	                                <option value="Past">Past</option>
	                            </select>
                              </div>
                              <div class="col">
                                  <label>Cataloge PDF upload </label>
                                  <input type="file" class="form-control" name="cataloge_pdf" required>
                                  @if($errors->has('cataloge_pdf'))
                                <div style="width: 100%" class="alert alert-danger alert-dismissible fade show" role="alert">{{ $errors->first('cataloge_pdf') }}
                                   <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                   <span aria-hidden="true">&times;</span>
                                   </button>
                                </div>
                                @endif
                              </div>
                            </div>
                           
                            <br>
                            <div class="form-row">
                              <div class="col">
                                <label>Start Date</label>
                                <input type="date" class="form-control"placeholder="Enter Title" name="start_date" required>
                              </div>
                              <div class="col">
                                <label>End Date</label>
                                <input type="date" class="form-control" placeholder="Enter Title" name="end_date" required>
                              </div>
                            </div>
                            <br>
                            <div class="form-row">
                              <div class="col">
                                <label>Thumbnail Image Outer</label>
                                <input type="file" class="form-control"  name="thumbnail_image[]" multiple required>
                              </div>
                              <div class="col">
                                <label>Big Image</label>
                                <input type="file" class="form-control"  name="big_image" required>
                                @if($errors->has('big_image'))
		                            <div style="width: 100%" class="alert alert-danger alert-dismissible fade show" role="alert">{{ $errors->first('big_image') }}
		                               <button type="button" class="close" data-dismiss="alert" aria-label="Close">
		                               <span aria-hidden="true">&times;</span>
		                               </button>
		                            </div>
		                            @endif
                              </div>
                            </div>
                            <br>
                            <div class="form-row">
                              <div class="col">
                                <label>Description</label>
                                <textarea name="editor1"></textarea>
                              </div>
                            </div>
                            
                            <br>
                            <div>
                                <button class="btn btn-primary">Add Auction</button>
                            </div>
                          </form>
                        </div>
                    </div>
@endsection