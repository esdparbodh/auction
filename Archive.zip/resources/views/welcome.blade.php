@extends('layouts.app')
@section('title', 'ArtDeal')
@section('homepage')
<!-- banner start -->
    <div class="banner-style-02">
        <div class="banner-slider-02 mb-0">
            <div>
                <div class="banner__bg2 d-flex align-items-center justify-content-center text-center" style="background: url('public/assets/img/banner/1.jpg') no-repeat center center/cover">
                    <div class="container-fluid px-5">
                        <div class="banner-content">
                            <h3 class="subtitle" data-animation-in="fadeInLeft">MAY 21 - 30, 2022</h3>
                            <h2 class="title" data-animation-in="fadeInRight">MODERN ART AUCTION</h2>
                            <div class="margin-top-50 pl-1">
                                <div class="btn-wrapper" data-animation-in="fadeInDown">
                                    <a class="btn btn-black" href="#">VIEW RESULTS</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div>
                <div class="banner__bg2 d-flex align-items-center justify-content-center text-center" style="background: url('public/assets/img/banner/2.jpg') no-repeat center center/cover">
                    <div class="container-fluid px-5">
                        <div class="banner-content">
                            <h3 class="subtitle" data-animation-in="fadeInLeft">MAY 27 - JUINE 30, 2022</h3>
                            <h2 class="title" data-animation-in="fadeInRight">MASTERS LEGACY</h2>
                            <div class="margin-top-50 pl-1">
                                <div class="btn-wrapper" data-animation-in="fadeInDown">
                                    <a class="btn btn-black" href="#">EXPLORE NOW</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- banner end -->
    
    <!-- tranding area start  -->
    <div class="tranding-area margin-top-70">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="section-title text-center margin-bottom-40">
                        <h3>UPCOMING AUCTIONS</h3>
                    </div>
                </div>
            </div>
           
           
        </div>
    </div>
    <!-- tranding area end  -->

   <!-- collection banner start  -->
    <div class="collection-banner">
        <div class="container">
            <div class="row">
                @foreach($UAuctions as $Uauction)
                <div class="col-lg-4">
                    <div class="collection-style-01 margin-top-20">
                        <div class="thumb">
                            <img src="public/assets/img/home/1.png" alt="">
                            <div class="content">
                                <h3>{{ strtoupper($Uauction->title) }}</h3>
                                <h6>{!! $Uauction->description !!}</h6>
                                <a href="{{ url('singleAuction')}}.{{$Uauction->id}}">explore more</a>
                            </div>
                        </div>
                    </div>
                </div>
                @endforeach
            </div>
        </div>
    </div>
    
    <div class="row">
                <div class="col-md-12">
                    <div class="btn-wrapper text-center margin-top-35">
                        <a href="#" class="btn btn-white">View All <i class="icon-arrow-buttom"></i></a>
                    </div>
                </div>
            </div>
    <!-- collection area end  -->

    

    <!-- collection section start  -->
    <div class="collection-section padding-top-70 padding-bottom-95">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="section-title text-center margin-bottom-40">
                        <h3>RECENT AUCTIONS</h3>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div class="collection-slider">
                        <div class="collection-item">
                            <div class="thumb">
                                <img src="public/assets/img/home/new1.jpg" alt="">
                                <div class="thumb-content">
                                    <div class="btn-wrapper">
                                        <a href="#" class="btn btn-white">VIEW RESULTS <i class="icon-arrow-buttom"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="collection-item">
                            <div class="thumb">
                                <img src="public/assets/img/home/new2.jpg" alt="">
                                <div class="thumb-content">
                                    <div class="btn-wrapper">
                                        <a href="#" class="btn btn-white">VIEW RESULTS <i class="icon-arrow-buttom"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="collection-item">
                            <div class="thumb">
                                <img src="public/assets/img/home/new3.jpg" alt="">
                                <div class="thumb-content">
                                    <div class="btn-wrapper">
                                        <a href="#" class="btn btn-white">VIEW RESULTS <i class="icon-arrow-buttom"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="collection-item">
                            <div class="thumb">
                                <img src="public/assets/img/home/new4.jpg" alt="">
                                <div class="thumb-content">
                                    <div class="btn-wrapper">
                                        <a href="#" class="btn btn-white">SHOP NOW <i class="icon-arrow-buttom"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- collection section end  -->

    <!-- arrivals area start  -->
    
    <!-- arrivals area end  -->

    <div class="video-area margin-top-30 margin-bottom-75">
        <div class="container">
            <div class="row justify-content-center text-center">
                <div class="col-md-12">
                    <div class="video-content" style="background: url('public/assets/img/home/video.jpg') no-repeat center center/cover">
                        <a href="#" class="video-btn-style-02"><i class="fa fa-play"></i></a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- article area start  -->
    <div class="article-area">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="section-title text-center margin-bottom-40">
                        <h3>LATEST NEWS</h3>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-4 col-md-6 col-sm-6 col-12">
                    <div class="article-style-01">
                        <div class="thumb">
                            <img src="public/assets/img/blog/1.png" alt="">
                            </div>
                        <div class="content">
                            <span class="date">June 24, 2020</span>
                            <h3><a href="#">Never putting your Art down to leave</a></h3>
                            <p>It reopened this year following a refurb which aims to cement its place a surfer’s paradise. It now boasts two.</p>
                            <div class="btn-wrapper">
                                <a href="#" class="btn">Read more</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-sm-6 col-12">
                    <div class="article-style-01">
                        <div class="thumb">
                            <img src="public/assets/img/blog/2.png" alt="">
                            </div>
                        <div class="content">
                            <span class="date">June 24, 2020</span>
                            <h3><a href="#">7 Things You Can’t Day Read</a></h3>
                            <p>Typography is the work of typesetters, compositors, typographers, graphic designers, art directors, manga</p>
                            <div class="btn-wrapper">
                                <a href="#" class="btn">Read more</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-sm-6 col-12">
                    <div class="article-style-01">
                        <div class="thumb">
                            <img src="public/assets/img/blog/3.png" alt="">
                            </div>
                        <div class="content">
                            <span class="date">June 24, 2020</span>
                            <h3><a href="#">Indian Contemporary Art Auction goes live</a></h3>
                            <p>It reopened this year following a refurb which aims to cement its place a surfer’s paradise. It now boasts two.</p>
                            <div class="btn-wrapper">
                                <a href="#" class="btn">Read more</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- article area end  -->


    
    <!-- brand-area start -->
   
    <!-- brand-area end -->

    <!-- contact area start  -->
    <div class="contact-area grey-bg margin-top-80">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-8">
                    <div class="contact-content-03 text-center padding-top-50 padding-bottom-60">
                        <div class="section-title-02">
                            <h3>KEEP CONNECTED</h3>
                        </div>
                        <h6>Subscribe to our newsletter and be the first to receive the latest art news, promotions and more!</h6>
                        @if(session()->has('message'))
                            <div class="alert alert-success">
                                {{ session()->get('message') }}
                            </div>
                        @endif
                        <form method="POST" action="{{ route('subscribeme') }}">
                            {{ csrf_field() }}
                            <div class="form-row align-items-center justify-content-center">
                              <div class="col-10 col-sm-8">
                              <div class="input-group">
                                  <input type="text" class="form-control" name="name" id="inlineFormInputGroup" placeholder="Name">
                                </div>
                                <div class="input-group">
                                  <input type="email" class="form-control" name="email" id="inlineFormInputGroup" placeholder="E-mail">
                                </div>
                                @if($errors->has('email'))
                            <div style="width: 100%" class="alert alert-danger alert-dismissible fade show" role="alert">{{ $errors->first('email') }}
                               <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                               <span aria-hidden="true">&times;</span>
                               </button>
                            </div>
                            @endif
                                <div class="btn-wrapper">
                                    <input type="submit" class="btn btn-yellow" value="SUBSCRIBE">
                                   
                                </div>
                              </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- contact area end  -->
@endsection