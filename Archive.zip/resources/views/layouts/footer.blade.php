 <footer class="footer-area footer-style-1 padding-top-70 margin-top-70">
        <div class="footer-top padding-bottom-50">
            <div class="container">
                <div class="row">
                    
                    <div class="col-lg-5 col-md-6">
                        <div class="widget contact-widget">
                            <h4 class="widget-title">GET IN TOUCH</h4>
                            <ul class="contact_info_list">
                                <li class="single-info-item">
                                    <div class="icon">
                                        <i class="icon-home-foother"></i>
                                    </div>
                                    <div class="details">
                                        <span>Hauzhas Village,<br>New Delhi - 110065<br>India</span>
                                    </div>
                                </li>
                                <li class="single-info-item">
                                    <div class="icon">
                                        <i class="icon-email-subscribe"></i>
                                    </div>
                                    <div class="details">
                                        info@artdealauctionhouse.com
                                    </div>
                                </li>
                                <li class="single-info-item">
                                    <div class="icon">
                                        <i class="icon-call-footer"></i>
                                    </div>
                                    <div class="details">
                                        <a href="">(+91) 11 1111111</a>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-5 col-md-6">
                        <div class="widget widget_nav_menu">
                            <h4 class="widget-title">CATEGORIES</h4>
                            <ul>
                                <li><a href="#">Privacy Policy</a></li>
                                <li><a href="#">Terms & Conditions</a></li>
                                <li><a href="#">Shipping & Delivery</a></li>
                                <li><a href="#">Faq</a></li>
                                </ul>
                        </div>
                    </div>
                    <div class="col-lg-2 col-md-6">
                        <div class="widget widget_nav_menu">
                            <h4 class="widget-title">FOLLOW US</h4>
                            <ul>
                                <li><a href="#"><i class="icon-facebook"></i> Facebook</a></li>
                                <li><a href="#"><i class="icon-skype"></i> Twitter</a></li>
                                <li><a href="#"><i class="icon-instagram"></i> Instagram</a></li>
                                <li><a href="#"><i class="icon-youtube"></i> Youtube</a></li>
                                </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="footer-bottom">
            <div class="container">
                <div class="row">
                    <div class="col-md-6 align-self-center">
                        <p>ARTDEAL auction house. All rights reserved</p>
                    </div>
                    <div class="col-md-6">
                        </div>
                </div>
            </div>
        </div>
    </footer>