<!DOCTYPE html>
<html lang="zxx">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
   
    <title>ARTDEAL auction house - @yield('title')</title>
    <!-- favicon -->
    <link rel=icon href="{{ url('public/assets/img/favicon1.png')}}" sizes="20x20" type="image/png">
    <!-- Vendor Stylesheet -->
    <link rel="stylesheet" href="{{ url('public/assets/css/vendor.css')}}">
    <!-- Main Stylesheet -->
    <link rel="stylesheet" href="{{ url('public/assets/css/style.css')}}">
    <!-- responsive Stylesheet -->
    <link rel="stylesheet" href="{{ url('public/assets/css/responsive.css')}}">
</head>
<body>

    <!-- preloader area start -->
    
    <!-- preloader area end -->

    <!-- search Popup -->
    <div class="body-overlay" id="body-overlay"></div>
    <div class="search-popup" id="search-popup">
        <form action="index.html" class="search-form">
            <div class="form-group">
                <input type="text" class="form-control" placeholder="Search.....">
            </div>
            <button type="submit" class="submit-btn"><i class="fa fa-search"></i></button>
        </form>
    </div>
    <!-- search Popup end -->

    <!--sidebar menu start-->
    <div class="sidebar-menu" id="sidebar-menu">
        <button class="sidebar-menu-close">X</button>
        <div class="sidebar-inner">
            <div class="sidebar-')}}">
                <img src="{{ url('public/assets/img/logo.png')}}" alt="">
            </div>
            <div class="sidemenu-text">
                <p>ARTDEAL auction house was established in the year..., it is a reputed auction house from India offering a...</p>
            </div>
            <div class="sidebar-contact">
                <h4>Contact Us</h4>
                <ul>
                    <li><i class="fa fa-map-marker"></i>New Delhi, India</li>
                    <li><i class="fa fa-envelope"></i>info@artdealauctionhouse.com</li>
                    <li><i class="fa fa-phone"></i>(+91) 11 11111111</li>
                </ul>
            </div>
           <div class="social-link">
                <ul>
                    <li><a href="#"><i class="fa fa-facebook-f"></i></a></li>
                    <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                    <li><a href="#"><i class="fa fa-instagram"></i></a></li>
                    <li><a href="#"><i class="fa fa-pinterest"></i></a></li>
                </ul>
            </div>
        </div>
    </div>
    <!--sidebar menu end-->

    <!-- navbar start -->
    @include('layouts.navbar')
    <!-- navbar end -->
    @yield('homepage')
    @yield('login')
    @yield('register')
    @yield('department')
    @yield('singleAuction')
    

    <!-- footer area start -->
   @include('layouts.footer')
    <!-- footer area end -->

    <!-- back to top area start -->
    <div class="back-to-top">
        <span class="back-top"><i class="fa fa-angle-up"></i></span>
    </div>
    <!-- back to top area end -->

    <!-- all plugins here -->
    <script src="{{ url('public/assets/js/vendor.js')}}"></script>
    <!-- main js  -->
    <script src="{{ url('public/assets/js/main.js')}}"></script>
</body>
</html>