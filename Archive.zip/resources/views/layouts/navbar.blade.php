<div class="stoon-navbar">
        <div class="header-top d-none d-sm-block">
            <div class="container-fluid">
                <div class="row align-items-center">
                    <div class="col-lg-4 col-8">
                        <div class="contact">
                            <a href=""><i class="icon-call-header"></i> (+91) 11 11111111</a>
                            <a href="#"><i class="icon-email-subscribe"></i> info@artdealauctionhouse.com</a>
                        </div>
                    </div>
                    <div class="col-lg-4 d-none d-lg-block">
                        <div class="shipping text-center">
                            </div>
                    </div>
                    <div class="col-lg-4 col-4">
                        <div class="social">
                            <ul class="nav-social justify-content-end">
                                <li><a href="#"><i class="icon-facebook"></i></a></li>
                                <li><a href="#"><i class="icon-instagram"></i></a></li>
                                <li><a href="#"><i class="icon-youtube"></i></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <nav class="navbar navbar-area navbar-expand-lg nav-style-01">
            <div class="container-fluid nav-container">
                <div class="row">
                    <div class="col-lg-2 col-4 order-1 align-self-center">
                        <div class="logo">
                            <a href="{{url('/')}}"><img src="{{ url('public/assets/img/logo.png')}}" alt=""></a>
                        </div>
                    </div>
                    <div class="col-lg-9 order-3 order-lg-2">
                        <div class="collapse navbar-collapse" id="shop-menu">
                            <ul class="navbar-nav menu-open">
                                <li class="menu-item-has-children">
                                    <a href="#">Auctions <i class="fa fa-angle-down"></i></a>
                                    <ul class="sub-menu">
                                        <li><a href="live-auctions.html">Live Auction</a></li>
                                        <li><a href="upcoming-auctions.html">Upcoming Auctions</a></li>
                                        <li><a href="past-auctions.html">Past Auctions</a></li>
                                        </ul>
                                </li>
                                <li><a href="{{ route('department')}}">Departments</a></li>
                                <li class="menu-item-has-children">
                                    <a href="#">Valuation <i class="fa fa-angle-down"></i></a>
                                    <ul class="sub-menu">
                                        <li><a href="blog.html">How to Buy?</a></li>
                                        <li><a href="blog-details.html">How to Sell?</a></li>
                                        <li><a href="blog-details.html">Free Evaluation</a></li>
                                        </ul>
                                </li>
                                <li class="menu-item-has-children">
                                    <a href="#">About ArtDeal <i class="fa fa-angle-down"></i></a>
                                    <ul class="sub-menu">
                                        <li><a href="collection.html">About Us</a></li>
                                        <li><a href="collection-list.html">Services</a></li>
                                        <li><a href="collection-list.html">Terms & Conditions</a></li>
                                        </ul>
                                </li>
                                <li><a href="news.html">News</a></li>
                                <li><a href="contact.html">Contact us</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-1 justify-content-end d-flex order-2 order-lg-3">
                        <div class="nav-right-part">
                            <ul>
                            <li>
                                    <a href="#" id="search"><i class="icon-search"></i></a>                                </li>
                            <li>
                                    <a href="#"><i class="icon-user"></i></a>
                                    <ul class="user-dropdown">
                                        @if (!Auth::guest())
                                            <li>
                                            @if(Auth::user()->role=='Admin')
                                                <a href="{{route('dashboard')}}">
                                            @else
                                                <a href="{{url('/')}}">
                                            @endif
                                            <i class="icon-user"></i> My Account ({{ucfirst(Auth::user()->name)}})</a></li>
                                        @if(Auth::user()->role != "Admin")
                                        <li><a href="#"><i class="fa fa-briefcase"></i> My Bids</a></li>
                                        @endif
                                        <li><a href="{{route('logout')}}"><i class="fa fa-sign-out"></i> Logout</a></li> 
                                        @else
                                            <li><a href="{{route('login')}}">User Login | Join</a></li>
                                            <!-- <li><a href="{{url('admin/login')}}">Admin Login</a></li> -->
                                        @endif
                                        
                                        
                                        </ul>
                                </li>
                              <li class="d-none d-lg-block">
                                    <a href="#" id="navigation-button"><i class="icon-bar-icon"></i></a>
                                </li>
                            </ul>
                        </div>
                        <div class="responsive-mobile-menu">
                            <div class="menu toggle-btn d-block d-lg-none" data-toggle="collapse" data-target="#shop-menu" aria-expanded="false" role="button">
                                <div class="icon-left"></div>
                                <div class="icon-right"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </nav>
    </div>