@extends('layouts.app')
@section('title', 'Login')
@section('login')
<!-- breadcrumb start  -->
    <div class="breadcrumb-areablack">
        <div class="container">
            <div class="row">
                <div class="col-md-12"></div>
            </div>
        </div>
    </div>
    <!-- breadcrumb end  -->
    
    @if(Request::is('admin/login'))
    <?php  ?>
    <!-- article area start  -->
    <div class="article-area margin-top-50">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="section-title-02 margin-bottom-10 text-center">
                        <h3>Admin Login </h3>
                    </div>
                </div>
            </div>
         </div>
    </div>
    @else
    <div class="article-area margin-top-50">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="section-title-02 margin-bottom-10 text-center">
                        <h3>MY ARTDEAL ACCOUNT</h3>
                        <h6>New to ARTDEAL?&nbsp;&nbsp;&nbsp;<a href="{{route('registration')}}" class="color-main">JOIN</a></h6>
                    </div>
                </div>
            </div>
         </div>
    </div>
    @endif
    <!-- article area end  -->
    
    <!-- contact area start  -->
    <div class="contact-area grey-bg margin-top-10">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-8">
                    <div class="contact-content-03 text-center padding-top-20 padding-bottom-50">
                        @if(session()->has('message'))
                            <div class="alert alert-danger">
                                {{ session()->get('message') }}
                            </div>
                        @endif
                        <form method="POST" action="{{ route('login') }}">
                        	{{ csrf_field() }}
                            @if(Request::is('admin/login'))
                            <input type="hidden" name="role" value="Admin">
                            @else
                            <input type="hidden" name="role" value="User">
                            @endif
                            <div class="form-row align-items-center justify-content-center">
                              <div class="col-10 col-sm-8">
                              <div class="input-group">
                                  <input type="text" class="form-control" id="inlineFormInputGroup" placeholder="Email Address" name="email">
                                </div>
                                <div class="input-group">
                                  <input type="text" class="form-control" id="inlineFormInputGroup" placeholder="Password" name="password">
                                </div>
                                <div class="btn-wrapper">
                                	<input type="submit" name="LOGIN" class="btn btn-yellow">
                                    
                                </div>
                              </div>
                            </div>
                        </form>
                        <!-- <h6><a href="registration.html" class="color-main">Forgot Password?</a></h6> -->
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- contact area end  -->
@endsection