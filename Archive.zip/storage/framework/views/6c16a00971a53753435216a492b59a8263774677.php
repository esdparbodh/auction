<?php $__env->startSection('title', 'Add Auction Details'); ?>
<?php $__env->startSection('AuctionDetails'); ?>
<style type="text/css">
	.SArtist{
		display: block;

	}
	.EArtist{ 
		display: none!important;
	}
	.DSArtist{
		display: none!important;
	}
	.DEArtist{
		display: block!important;
	}
</style>
<!-- Page Heading -->
                    
                        <h1 class="h3 mb-2 text-gray-800">Add Art Detail</h1>
                   
                    
                    <!-- <p class="mb-4">DataTables is a third party plugin that is used to generate the demo table below.
                        For more information about DataTables, please visit the <a target="_blank"
                            href="https://datatables.net">official DataTables documentation</a>.</p>
 -->
                    <!-- DataTales Example -->
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <!-- <h6 class="m-0 font-weight-bold text-primary">DataTables Example</h6> -->
                        </div>
                        <div class="card-body">
                            <?php if(session()->has('message')): ?>
            						        <div class="alert alert-success">
            						            <?php echo e(session()->get('message')); ?>

            						        </div>
            						    <?php endif; ?>
                            <form action="<?php echo e(route('addActionDetails')); ?>" method="POST" enctype="multipart/form-data">
                            	<?php echo e(csrf_field()); ?>

                            	
                            <div class="form-row">
                              <div class="col" >
                                <label>Department</label>
                                <select class="form-control" name="department">
                                  <option>Select </option>
                                  <?php $__currentLoopData = $data3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datas3): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($datas3->title); ?>"><?php echo e($datas3->title); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                              </div>
                              <div class="col">
                                <label>Auction Type</label>
                                <select class="form-control" id="ArtType" name="ArtType" >
                                    <option>Select </option>
                                    <option value="Upcoming">Upcoming</option>
                                    <option value="Live">Live</option>
                                    <option value="Past">Past</option>
                                </select>
                              </div>
                              
                            </div> 
                            <br> 
                            <div class="form-row">
                              <div class="col">
                                <label>Auction </label>
                                <select id="artTYPe" class="form-control" name="Auction">
                                </select>
                              </div>
                              <div class="col">
                                <label>Enter Title</label>
                                <input class="form-control" type="text" name="title">
                              </div>
                            </div>
                            <br>
                            <div class="form-row">
                              <div class="col">
                                <label>Art Auction Type</label>
                                <select class="form-control" id="AType" name="AuctionType" >
                                    <!-- <option>Select </option> -->
                                    <option value="Art Auction" selected>Art Auction</option>
                                    <option value="Other Auction">Other Auction</option>
                                </select>
                              </div>
                              <div class="col" id="SArt">
                                <label>Select Artist</label>
                                <select class="form-control" name="artist">
                                	<option>Select </option>
                                	<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($datas->name); ?>"><?php echo e($datas->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                              </div>
                              <div class="col" id="EArt" >
                                <label>Enter Artist</label>
                                <input class="form-control" type="text" name="artist">
                              </div>
                            </div>
              							  <br>
              							<div class="form-row">
                              <div class="col">
                                <label>Enter Lot</label>
                                <input type="text" class="form-control" name="lot" required >
                              </div>
                              <div class="col">
                                <label>Enter Code</label>
                                <input type="text" class="form-control" name="code" required >
                              </div>
                            </div>
							<br>
							<div class="form-row">
                              <div class="col">
                                <label>Auction Picture's</label>
                                <input type="file" class="form-control"  name="images[]" multiple>
                              </div>
                              <div class="col">
                                <label>Enter Year</label>
                                <input type="text" class="form-control" name="year">
                              </div>
                            </div>
                            <br>
							<div class="form-row">
                              <div class="col">
                                <label>Medium</label>
                                <select class="form-control" name="medium" required>
                                  <option>Select </option>
                                  <?php $__currentLoopData = $data2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data2s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($data2s->title); ?>"><?php echo e($data2s->title); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                
                              </div>
                              <div class="col">
                                
                                <div class="d-inline-flex p-3">
                                	<label>Size (HxWxD)</label>
								  <div class="p-2"><input type="number" class="form-control"name="height" required ></div>
								  <div class="p-2"><input type="number" class="form-control"name="width" required ></div>
								  <div class="p-2"><input type="number" class="form-control"name="depth" required ></div>
								</div>
                                
                              </div>
                            </div>
							<br>
							<div class="form-row">
                              <div class="col">
                                <label>Estimation Price Start</label>
                                <input type="number" class="form-control" name="price_start" required >
                              </div>
                              <div class="col">
                                <label>Estimation Price Upto</label>
                                <input type="number" class="form-control" name="price_upto" required >
                              </div>
                            </div>
                            
                            <br>
                            <div class="form-row">
                              <div class="col">
                                <label>Description</label>
                               <textarea name="editor1"></textarea>
                              </div>
                            </div>
                            <br>
                            <div>
                            	<input type="submit" class="btn btn-primary" name="Add Auction Details">
                            </div>
                          </form>
                        </div>
                    </div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script type="text/javascript">
	$('#SArt').addClass('SArtist');
	$('#EArt').addClass('EArtist');
	$('#AType').on('change', function()
	{
		var AuctionId = this.value;
		if(AuctionId == "Art Auction"){
      $('#SArt').removeClass('DSArtist');
			$('#SArt').addClass('SArtist');
      $('#EArt').removeClass('DEArtist');
			$('#EArt').addClass('EArtist');
		}else{
      $('#SArt').removeClass('SArtist');
			$('#SArt').addClass('DSArtist');
      $('#EArt').removeClass('EArtist');
			$('#EArt').addClass('DEArtist');
		}
	});

  $('#ArtType').on('change', function()
  {
    var artval = this.value;
     $.ajax({
       url: "<?php echo url('/getauctions'); ?>", 
       type: "POST",
       dataType: "json",
       contentType: "application/json; charset=utf-8",
       data: JSON.stringify({ AuctionType: artval,'_token':"<?php echo e(csrf_token()); ?>" }),
       success: function (result) {
        // console.log(result)
        $("#artTYPe").empty();
        $.each(result,function ( index, repo ) {

            $('#artTYPe').append(`
            <option value="${repo.title}">${repo.title}</option>
                `)
        });
       
        },
        error: function (err) {
        // check the err for error details
        }
     }); 
  });
	
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/auction/resources/views/dashboard/auctionDetails.blade.php ENDPATH**/ ?>