<?php $__env->startSection('title', 'Add Auction'); ?>
<?php $__env->startSection('allAuctions'); ?>
	<!-- Page Heading -->
                    <div class="form-row">
                        <div class="col"><h1 class="h3 mb-2 text-gray-800">All Auctions</h1></div>
                    <div class="col1"><a href="<?php echo e(route('addAuction')); ?>" class="btn btn-primary btn-icon-split">
                            <span class="text">Add Auction</span></a></div>
							</div>
                    
                    <!-- <p class="mb-4">DataTables is a third party plugin that is used to generate the demo table below.
                        For more information about DataTables, please visit the <a target="_blank"
                            href="https://datatables.net">official DataTables documentation</a>.</p>
 -->
                    <!-- DataTales Example -->
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <!-- <h6 class="m-0 font-weight-bold text-primary">DataTables Example</h6> -->
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">

                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th width="18%">Auction Name</th>
                                            <th width="13%">
				                                <select class="form-control">
				                                    <option>Select </option>
				                                    <option>All</option>
													<option>Live</option>
				                                    <option>Upcoming</option>
				                                    <option>Past</option>
				                                </select> </th>
                                            <th width="18%">Department</th>
                                            <th width="14%">Start Date</th>
                                            
                                            <th width="12%">End Date </th>
                                            
                                            <th width="20%">Action</th>
                                        </tr>
                                    </thead>
                                    
                                    <tbody>
                                    	<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e(ucfirst($datas->title)); ?> </td>
                                            <td><?php echo e($datas->type); ?></td>
                                            <td><?php echo e($datas->department); ?></td>
                                            <td><?php echo e($datas->start_date); ?></td>
                                            
                                            <td><?php echo e($datas->end_date); ?></td>
                                            
                                            
                                            <td align="center"><a href="#">Edit</a> | <a href="#">Delete</td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/auction/resources/views/dashboard/allAuctions.blade.php ENDPATH**/ ?>