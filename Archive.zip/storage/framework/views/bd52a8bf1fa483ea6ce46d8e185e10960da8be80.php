<?php $__env->startSection('title', 'All Artist'); ?>
<?php $__env->startSection('AddArtist'); ?>
<!-- Page Heading -->
                    
                        <h1 class="h3 mb-2 text-gray-800">Add Artist</h1>
                   
                    
                    <!-- <p class="mb-4">DataTables is a third party plugin that is used to generate the demo table below.
                        For more information about DataTables, please visit the <a target="_blank"
                            href="https://datatables.net">official DataTables documentation</a>.</p>
 -->
                    <!-- DataTales Example -->
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <!-- <h6 class="m-0 font-weight-bold text-primary">DataTables Example</h6> -->
                        </div>
                        <div class="card-body">
                            <?php if(session()->has('message')): ?>
            						        <div class="alert alert-success">
            						            <?php echo e(session()->get('message')); ?>

            						        </div>
            						    <?php endif; ?>
                              <form action="<?php echo e(Request::is('addArtist') ? route('AddArtist') : route('editArtist')); ?>" method="post" enctype="multipart/form-data">
                            	<?php echo e(csrf_field()); ?> 

                              <input type="hidden" name="id" value="<?php echo e(Request::is('addArtist') ? '' : $data[0]->id); ?>">
                            <div class="form-row">
                              <div class="col">
                                <label>Enter Artist Name<span style="color:red">*</span></label>
                                <input type="text" class="form-control" id="email" name="name" value="<?php echo e(Request::is('addArtist') ? '' : $data[0]->name); ?>"required >
                              </div>
                              <div class="col">
                                <label>Photo <span style="color:red">*</span></label>
                                <input type="file" class="form-control" name="image" required>
                              </div>
                            </div>
                            <br>
                            <div class="form-row">
                              <div class="col">
                                <label>Date Of Birth</label>
                                <input type="date" class="form-control" id="email" name="dob" placeholder="Enter Title" value="<?php echo e(Request::is('addArtist') ? '' : $data[0]->dob); ?>" required>
                              </div>
                              <div class="col">
                                <label>Death Date (If applicable)</label>
                                <input type="date" class="form-control" placeholder="Enter description" name="dod" value="<?php echo e(Request::is('addArtist') ? '' : $data[0]->dod); ?>">
                              </div>
                            </div>
                            <br>
                            <div class="form-row">
                              <div class="col">
                                <label>Description</label>
                               <textarea name="editor1" required><?php echo Request::is('addArtist') ? '' : $data[0]->description; ?></textarea>
                                
                              </div>
                              
                            </div>
                            <br>
                            <div>
                                <button type="submit" class="btn btn-primary" ><?php echo e(Request::is('addDepartments') ? 'Add Artist' : 'Update Artist'); ?></button>
                            </div>
                            
                          </form>
                        </div>
                    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/auction/resources/views/dashboard/addArtist.blade.php ENDPATH**/ ?>