<!-- Sidebar -->
        <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

            <!-- Sidebar - Brand -->
            <a class="sidebar-brand d-flex align-items-center justify-content-center" href="index.html">
                <div class="sidebar-brand-icon rotate-n-15">
                    <i class="fas fa-laugh-wink"></i>
                </div>
                <div class="sidebar-brand-text mx-3">ARTDeal</div>
            </a>

            <!-- Divider -->
            <hr class="sidebar-divider my-0">

            <!-- Nav Item - Dashboard -->
            <li class="nav-item active">
                <a class="nav-link" href="<?php echo e(url('/dashboard')); ?>">
                    <i class="fas fa-fw fa-tachometer-alt"></i>
                    <span>Dashboard</span></a>
            </li>

            <!-- Divider -->
            <hr class="sidebar-divider">

            <!-- Heading -->
            <div class="sidebar-heading">
                Interface
            </div>
            
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('allSliders')); ?>">
                    <i class="fas fa-fw fa-home"></i>
                    <span>Homepage</span></a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('allDepartments')); ?>">
                    <i class="fas fa-fw fa-building"></i>
                    <span>Departments</span></a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('allMediums')); ?>">
                    <i class="fas fa-fw fa-building"></i>
                    <span>Medium</span></a>
            </li>
            
            <!-- Nav Item - Pages Collapse Menu -->
             <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('allArtists')); ?>">
                    <i class="fas fa-fw fa-user"></i>
                    <span>Artists</span></a>
            </li>
            
            </li>
            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseTwo"
                    aria-expanded="true" aria-controls="collapseTwo">
                    <i class="fas fa-fw fa-building"></i>
                    <span>Auction</span>
                </a>
                <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <!-- <h6 class="collapse-header">Custom Components:</h6> -->
                        <a class="collapse-item" href="<?php echo e(route('allAuctions')); ?>">All Auctions</a>
                        <a class="collapse-item" href="<?php echo e(route('allArts')); ?>">All Arts</a>
                        <!-- <a class="collapse-item" href="<?php echo e(route('auctionDetails')); ?>">Add Art</a> -->
                        
                    </div>
                </div>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="allVideos.html">
                    <i class="fas fa-fw fa-chart-area"></i>
                    <span>Videos</span></a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="allNews.html">
                    <i class="fas fa-fw fa-chart-area"></i>
                    <span>News</span></a>
            </li>
            <li class="nav-item">
               <a class="nav-link" href="<?php echo e(route('allUsers')); ?>">
                    <i class="fas fa-fw fa-chart-area"></i>
                    <span>Users</span></a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('newsletter')); ?>">
                    <i class="fas fa-fw fa-chart-area"></i>
                    <span>Newsletter</span></a>
            </li>
            
            
            
        </ul>
        <!-- End of Sidebar --><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/auction/resources/views/dashboard/layouts/sidebar.blade.php ENDPATH**/ ?>