<?php $__env->startSection('title', 'Add Medium'); ?>
<?php $__env->startSection('addMedium'); ?>
<!-- Page Heading -->
                    
                        <h1 class="h3 mb-2 text-gray-800">Add Medium</h1>
                    <!-- DataTales Example -->
                    <?php if(session()->has('message')): ?>
				        <div class="alert alert-success">
				            <?php echo e(session()->get('message')); ?>

				        </div>
				    <?php endif; ?>
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <!-- <h6 class="m-0 font-weight-bold text-primary">DataTables Example</h6> -->
                        </div>
                        <div class="card-body">
                            
                            <form action="<?php echo e(Request::is('addMediums') ? route('addMedium') : route('editMedium')); ?>" method="post">
                                <?php echo e(csrf_field()); ?>

                                <input type="hidden" name="id" value="<?php echo e(Request::is('addMediums') ? '' : $data[0]->id); ?>">
                            <div class="form-row">
                              <div class="col">
							  <label>Enter Title</label>
                                <input type="text" class="form-control" id="title" placeholder="Enter Title" name="title" value="<?php echo e(Request::is('addMediums') ? '' : $data[0]->title); ?>">
                              </div>
                            </div>
							<br>
                               <!--  <label>Description</label>
                                <textarea name="editor1" ><?php echo Request::is('addMediums') ? '' : $data[0]->description; ?></textarea>
                            <br> -->
                            <div>
                                <button type="submit" class="btn btn-primary" ><?php echo e(Request::is('addMediums') ? 'Add Medium' : 'Update Medium'); ?></button>
                            </div>
                            
                          </form>
                        </div>
                    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/auction/resources/views/dashboard/addMedium.blade.php ENDPATH**/ ?>