<!DOCTYPE html>
<html lang="zxx">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
   
    <title>ARTDEAL auction house - <?php echo $__env->yieldContent('title'); ?></title>
    <!-- favicon -->
    <link rel=icon href="<?php echo e(url('public/assets/img/favicon1.png')); ?>" sizes="20x20" type="image/png">
    <!-- Vendor Stylesheet -->
    <link rel="stylesheet" href="<?php echo e(url('public/assets/css/vendor.css')); ?>">
    <!-- Main Stylesheet -->
    <link rel="stylesheet" href="<?php echo e(url('public/assets/css/style.css')); ?>">
    <!-- responsive Stylesheet -->
    <link rel="stylesheet" href="<?php echo e(url('public/assets/css/responsive.css')); ?>">
</head>
<body>

    <!-- preloader area start -->
    
    <!-- preloader area end -->

    <!-- search Popup -->
    <div class="body-overlay" id="body-overlay"></div>
    <div class="search-popup" id="search-popup">
        <form action="index.html" class="search-form">
            <div class="form-group">
                <input type="text" class="form-control" placeholder="Search.....">
            </div>
            <button type="submit" class="submit-btn"><i class="fa fa-search"></i></button>
        </form>
    </div>
    <!-- search Popup end -->

    <!--sidebar menu start-->
    <div class="sidebar-menu" id="sidebar-menu">
        <button class="sidebar-menu-close">X</button>
        <div class="sidebar-inner">
            <div class="sidebar-')}}">
                <img src="<?php echo e(url('public/assets/img/logo.png')); ?>" alt="">
            </div>
            <div class="sidemenu-text">
                <p>ARTDEAL auction house was established in the year..., it is a reputed auction house from India offering a...</p>
            </div>
            <div class="sidebar-contact">
                <h4>Contact Us</h4>
                <ul>
                    <li><i class="fa fa-map-marker"></i>New Delhi, India</li>
                    <li><i class="fa fa-envelope"></i>info@artdealauctionhouse.com</li>
                    <li><i class="fa fa-phone"></i>(+91) 11 11111111</li>
                </ul>
            </div>
           <div class="social-link">
                <ul>
                    <li><a href="#"><i class="fa fa-facebook-f"></i></a></li>
                    <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                    <li><a href="#"><i class="fa fa-instagram"></i></a></li>
                    <li><a href="#"><i class="fa fa-pinterest"></i></a></li>
                </ul>
            </div>
        </div>
    </div>
    <!--sidebar menu end-->

    <!-- navbar start -->
    <?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- navbar end -->
    <?php echo $__env->yieldContent('homepage'); ?>
    <?php echo $__env->yieldContent('login'); ?>
    <?php echo $__env->yieldContent('register'); ?>
    <?php echo $__env->yieldContent('department'); ?>
    <?php echo $__env->yieldContent('singleAuction'); ?>
    

    <!-- footer area start -->
   <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- footer area end -->

    <!-- back to top area start -->
    <div class="back-to-top">
        <span class="back-top"><i class="fa fa-angle-up"></i></span>
    </div>
    <!-- back to top area end -->

    <!-- all plugins here -->
    <script src="<?php echo e(url('public/assets/js/vendor.js')); ?>"></script>
    <!-- main js  -->
    <script src="<?php echo e(url('public/assets/js/main.js')); ?>"></script>
</body>
</html><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/auction/resources/views/layouts/app.blade.php ENDPATH**/ ?>