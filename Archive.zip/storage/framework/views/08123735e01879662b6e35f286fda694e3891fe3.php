<?php $__env->startSection('title', 'Registration'); ?>
<?php $__env->startSection('register'); ?>
<!-- breadcrumb start  -->
    <div class="breadcrumb-areablack">
        <div class="container">
            <div class="row">
                <div class="col-md-12"></div>
            </div>
        </div>
    </div>
    <!-- breadcrumb end  -->
    

    <!-- article area start  -->
    <div class="article-area margin-top-50">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="section-title-02 margin-bottom-30 text-center">
                        <h3>YOUR ARTDEAL ACCOUNT</h3>
                        <h6>Please fill in the following details to create an account</h6>
                    </div>
                </div>
            </div>
         </div>
    </div>
    <!-- article area end  -->
    
    <!-- contact form start  -->
    <?php if(session()->has('message')): ?>
        <div class="alert alert-success">
            <?php echo e(session()->get('message')); ?>

        </div>
    <?php endif; ?>
    <div class="contact-form text-center padding-top-80 padding-bottom-80">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <form action="<?php echo e(route('register')); ?>" method="post">
                    	<?php echo e(csrf_field()); ?>

                        <div class="form-row">
                          <div class="form-group col-md-6">
                            <input type="text" class="form-control" name="name" placeholder="Name*" value="<?php echo e(session('auto', '')); ?>" required>
                          </div>
                          <div class="form-group col-md-6">
                            <input type="email" class="form-control" name="email" placeholder="Email (This will be Your Username)*" required>
                            <?php if($errors->has('email')): ?>
                            <div style="width: 100%" class="alert alert-danger alert-dismissible fade show" role="alert"><?php echo e($errors->first('email')); ?>

                               <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                               <span aria-hidden="true">&times;</span>
                               </button>
                            </div>
                            <?php endif; ?>
                          </div>
                        </div>
                        <?php if($errors->has('password')): ?>
                        <div style="width: 100%" class="alert alert-danger alert-dismissible fade show" role="alert"><?php echo e($errors->first('password')); ?>

                           <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                           <span aria-hidden="true">&times;</span>
                           </button>
                        </div>
                        <?php endif; ?>
                        <div class="form-row">
                          <div class="form-group col-md-6">
                            <input type="text" class="form-control" name="password" placeholder="Password*" required>
                          </div>
                          <div class="form-group col-md-6">
                            <input type="text" class="form-control" name="cpassword" placeholder="Confirm Password*" required>
                          </div>
                        </div>
                        
                        
                        <div class="form-row">
                          <div class="form-group col-md-6">
                            <input type="number" class="form-control" name="mobile" placeholder="Mobile Number*" required>
                            <?php if($errors->has('mobile')): ?>
                            <div style="width: 100%" class="alert alert-danger alert-dismissible fade show" role="alert"><?php echo e($errors->first('mobile')); ?>

                               <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                               <span aria-hidden="true">&times;</span>
                               </button>
                            </div>
                            <?php endif; ?>
                          </div>
                          <div class="form-group col-md-6">
                            <input type="text" class="form-control" name="country" placeholder="Country*" required>
                          </div>
                          </div>
                        
                        <div class="form-row">
                          <div class="form-group col-md-6">
                            <input type="text" class="form-control" name="house_address" placeholder="Flat No. / House No. / Building Name*" required>
                          </div>
                          <div class="form-group col-md-6">
                            <input type="text" class="form-control" name="street_area_address" placeholder="Street Name / Area Name*" required> 
                          </div>
                        </div>
                        
                        <div class="form-row">
                          <div class="form-group col-md-6">
                            <input type="text" class="form-control" name="state" placeholder="State*" required>
                          </div>
                        </div>
                        
                        <div class="form-row">
                          <div class="form-group col-md-6">
                            <input type="text" class="form-control" name="city" placeholder="City*" required>
                          </div>
                          <div class="form-group col-md-6">
                            <input type="text" class="form-control" name="pincode" placeholder="Postal Code*" required>
                          </div>
                        </div>
                        
                        
                        <button type="submit" class="btn btn-contact">SUBMIT</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <!-- contact form end  -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/auction/resources/views/registration.blade.php ENDPATH**/ ?>