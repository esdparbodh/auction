<?php $__env->startSection('title', 'All Artist'); ?>
<?php $__env->startSection('allartist'); ?>
<!-- Page Heading -->
                    <div class="form-row">
                        <div class="col"><h1 class="h3 mb-2 text-gray-800">All Artist</h1></div>
                    <div class="col1"><a href="<?php echo e(route('addArtist')); ?>" class="btn btn-primary btn-icon-split">
                            <span class="text">Add Artist</span></a></div>
							</div>
                    
                    <!-- <p class="mb-4">DataTables is a third party plugin that is used to generate the demo table below.
                        For more information about DataTables, please visit the <a target="_blank"
                            href="https://datatables.net">official DataTables documentation</a>.</p>
 -->
                    <!-- DataTales Example -->
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <!-- <h6 class="m-0 font-weight-bold text-primary">DataTables Example</h6> -->
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">

                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th width="28%">Artist Name</th>
                                            <th width="28%">Photo</th>
                                            <th width="14%">Description</th>
                                            <th width="16%">Date of Birth </th>
                                            
                                            <th width="19%">Date of Death </th>
                                            <th width="23%">Action</th>
                                        </tr>
                                    </thead>
                                    
                                    <tbody>
                                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e(ucfirst($datas->name)); ?></td>
                                            <td><img style="height: 50px;width: 50px;" src="<?php echo url('/public/images/artist');?>/<?php echo e($datas->image); ?>"></td>
                                            <td><?php echo $datas->description; ?></td>
                                            <td><?php echo e($datas->dob); ?></td>
                                            
                                            <td><?php echo e($datas->dod); ?></td>
                                            <td align="center"><a href="<?php echo e(url('editArtists')); ?>.<?php echo e($datas->id); ?>">Edit</a> |  <a href="#" onclick="deleteDep(<?php echo e($datas->id); ?>)">Delete</a></td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    <script type="text/javascript">
    function deleteDep(id) {
        // alert(id);
        Swal.fire({
          title: 'Are you sure?',
          text: "You won't be able to revert this!",
          icon: 'warning',
          showCancelButton: true,
          confirmButtonColor: '#3085d6',
          cancelButtonColor: '#d33',
          confirmButtonText: 'Yes, delete it!'
        }).then((result) => {
          if (result.isConfirmed) {
            var postForm = { //Fetch form data
                "_token": "<?php echo e(csrf_token()); ?>",
                'id'     : id //Store name fields value
            };
            $.ajax({
                url: "<?php echo url('/deleteArtist'); ?>",
                type: "post",
                data:  postForm,
                success: function (response) {
                    Swal.fire(
                      'Deleted!',
                      'Your file has been deleted.',
                      'success'
                    )
                    $(document).ready(function() {
                      setTimeout(function() {
                        location.reload();
                      }, 2000);
                    });
                     
                   // You will get response from your PHP page (what you echo or print)
                },
                error: function(jqXHR, textStatus, errorThrown) {
                   console.log(textStatus, errorThrown);
                }
            });
            
          }
        })
    }
    
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/auction/resources/views/dashboard/allArtist.blade.php ENDPATH**/ ?>