<?php $__env->startSection('title', 'Add Slider'); ?>
<?php $__env->startSection('AddSlider'); ?>
<!-- Page Heading -->
                    
                        <h1 class="h3 mb-2 text-gray-800">Add Slider</h1>
                   
                    
                    <!-- <p class="mb-4">DataTables is a third party plugin that is used to generate the demo table below.
                        For more information about DataTables, please visit the <a target="_blank"
                            href="https://datatables.net">official DataTables documentation</a>.</p>
 -->
                    <!-- DataTales Example -->
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <!-- <h6 class="m-0 font-weight-bold text-primary">DataTables Example</h6> -->
                        </div>
                        <div class="card-body">
                            <?php if(session()->has('message')): ?>
            						        <div class="alert alert-success">
            						            <?php echo e(session()->get('message')); ?>

            						        </div>
            						    <?php endif; ?>
                              <form action="<?php echo e(Request::is('addSlider') ? route('addSlider') : route('addSlider')); ?>" method="post" enctype="multipart/form-data">
                            	<?php echo e(csrf_field()); ?> 

                              <input type="hidden" name="id" value="<?php echo e(Request::is('addSlider') ? '' : $data[0]->id); ?>">
                            <div class="form-row">
                              <div class="col">
                                <label>Enter Slider Name<span style="color:red">*</span></label>
                                <input type="text" class="form-control" id="email" name="name" value="<?php echo e(Request::is('addSlider') ? '' : $data[0]->name); ?>"required >
                              </div>
                              
                            </div>
                            <br>
                            <div class="form-row">
                              <div class="col">
                                <label>Slider Image <span style="color:red">*</span></label>
                                <input type="file" class="form-control" name="image" required>
                              </div>
                              <div class="col">
                                <label>Button Name</label>
                                <input type="text" class="form-control"  name="buttonName" value="<?php echo e(Request::is('addSlider') ? '' : $data[0]->button_name); ?>">
                              </div>
                            </div>
                            <br>
                            <div>
                                <button type="submit" class="btn btn-primary" ><?php echo e(Request::is('addSlider') ? 'Add Slider' : 'Update Slider'); ?></button>
                            </div>
                            
                          </form>
                        </div>
                    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/auction/resources/views/dashboard/addSlider.blade.php ENDPATH**/ ?>