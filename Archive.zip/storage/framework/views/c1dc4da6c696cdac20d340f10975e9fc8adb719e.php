<?php $__env->startSection('title', 'Upload Art Images'); ?>
<?php $__env->startSection('Uploadartimage'); ?>
<style type="text/css">
	.hideDIvebrowse{
		display: none;
	}
	.ShowDIvebrowse{
		display: block!important;
	}
</style>
<!-- Page Heading -->
                    
                        <h1 class="h3 mb-2 text-gray-800">Add Artist</h1>
                   
                    
                    <!-- <p class="mb-4">DataTables is a third party plugin that is used to generate the demo table below.
                        For more information about DataTables, please visit the <a target="_blank"
                            href="https://datatables.net">official DataTables documentation</a>.</p>
 -->
                    <!-- DataTales Example -->
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <!-- <h6 class="m-0 font-weight-bold text-primary">DataTables Example</h6> -->
                        </div>
                        <div class="card-body">
                            <?php if(session()->has('message')): ?>
						        <div class="alert alert-success">
						            <?php echo e(session()->get('message')); ?>

						        </div>
						    <?php endif; ?>
                            <form action="<?php echo e(route('addImagesArt')); ?>" method="POST" enctype="multipart/form-data">
                            	<?php echo e(csrf_field()); ?>

                            <input type="hidden" name="id" value="<?php echo e($data[0]->id); ?>">
                            <div class="form-row">
                              <div class="col">
                                <label>Select Image Type</label>
                                 <select class="form-control" id="selectImageType" name="selectImageType">
                                    <option value="">Select </option>
                                    <option value="Thumbnail">Thumbnail</option>
                                    <option value="Big Image">Big Image</option>
                                    <option value="Blowup 1">Blowup 1</option>
									<option value="Blowup 2">Blowup 2</option>
									<option value="Blowup 3">Blowup 3</option>
									<option value="Blowup 4">Blowup 4</option>
                                </select>
                              </div>
                              <div class="col hideDIvebrowse" id="browse">
                                <label>Browse</label>
                                <input type="file" class="form-control" name="image" id="IMGfile" required>
                              </div>
                            </div>
							<br>
                            <div>
                                <button class="btn btn-primary">Add Image</button>
                            </div>
                            
                            <?php if($data[0]->images != null): ?>
                            <br>
                            <div class="form-row">
                              <div class="col">
                                <label>Thumbnail Images Preview</label>
								<div class="col">
                               <img style="width: 200px;height: 80px;" src="<?php echo e(url('/')); ?>/public/images/auctionDetails/" alt="Preview">
							   </div>
                              </div>
                            </div>
                            <?php endif; ?>
                            <?php if($data[0]->big_image != null): ?>
                            <br>
                            <div class="form-row">
                              <div class="col">
                                <label>Big Images Preview</label>
								<div class="col">
                               <img style="width: 200px;height: 80px;" src="<?php echo e(url('/')); ?>/public/images/auctionDetails/<?php echo e($data[0]->big_image); ?>" alt="Preview">
							   </div>
                              </div>
                            </div>
                            <?php endif; ?>
                            <?php if($data[0]->b1 != null): ?>
                            <br>
                            <div class="form-row">
                              <div class="col">
                                <label>Blowup 1 Images Preview</label>
								<div class="col">
                               <img style="width: 200px;height: 80px;" src="<?php echo e(url('/')); ?>/public/images/auctionDetails/<?php echo e($data[0]->b1); ?>" alt="Preview">
							   </div>
                              </div>
                            </div>
                            <?php endif; ?>
                            <?php if($data[0]->b2 != null): ?>
                            <br>
                            <div class="form-row">
                              <div class="col">
                                <label>Blowup 2 Images Preview</label>
								<div class="col">
                               <img style="width: 200px;height: 80px;" src="<?php echo e(url('/')); ?>/public/images/auctionDetails/<?php echo e($data[0]->b2); ?>" alt="Preview">
							   </div>
                              </div>
                            </div>
                            <?php endif; ?>
                            <?php if($data[0]->b3 != null): ?>
                            <br>
                            <div class="form-row">
                              <div class="col">
                                <label>Blowup 3 Images Preview</label>
								<div class="col">
                               <img style="width: 200px;height: 80px;" src="<?php echo e(url('/')); ?>/public/images/auctionDetails/<?php echo e($data[0]->b3); ?>" alt="Preview">
							   </div>
                              </div>
                            </div>
                            <?php endif; ?>
                            <?php if($data[0]->b4 != null): ?>
                            <br>
                            <div class="form-row">
                              <div class="col">
                                <label>Blowup 4 Images Preview</label>
								<div class="col">
                               <img style="width: 200px;height: 80px;" src="<?php echo e(url('/')); ?>/public/images/auctionDetails/<?php echo e($data[0]->b4); ?>" alt="Preview">
							   </div>
                              </div>
                            </div>
                            <?php endif; ?>
                            
                            </form>
                        </div>
                    </div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script type="text/javascript">
	$('#selectImageType').on('change', function()
	{
		var SelectedImageType = this.value;
		//alert(SelectedImageType);
		if(SelectedImageType != null){
			if(SelectedImageType == 'Thumbnail'){
				$('#IMGfile').attr('multiple', true);

			}else{

			}
     		$('#browse').removeClass('hideDIvebrowse');
			$(this).addClass('ShowDIvebrowse');
		}
	});
	
	
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/auction/resources/views/dashboard/uploadArtimages.blade.php ENDPATH**/ ?>