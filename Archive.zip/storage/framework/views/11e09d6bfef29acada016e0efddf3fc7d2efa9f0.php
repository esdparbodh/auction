<?php $__env->startSection('title', 'All Users'); ?>
<?php $__env->startSection('AllUsers'); ?>
<!-- Page Heading -->
                    
                        <h1 class="h3 mb-2 text-gray-800">All Users</h1>
                    
                    <!-- <p class="mb-4">DataTables is a third party plugin that is used to generate the demo table below.
                        For more information about DataTables, please visit the <a target="_blank"
                            href="https://datatables.net">official DataTables documentation</a>.</p>
 -->
                    <!-- DataTales Example -->
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <!-- <h6 class="m-0 font-weight-bold text-primary">DataTables Example</h6> -->
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">

                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                        	<th>Id</th>
                                            <th>Name</th>
                                            <th>Phone</th>
                                            <th>Email</th>
                                            <th>Status</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    
                                    <tbody>
                                    	<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($datas->id); ?> </td>
                                            <td><?php echo e(ucfirst($datas->name)); ?></td>
                                            <td><?php echo e($datas->mobile); ?></td>
                                            <td><?php echo e($datas->email); ?></td>
                                            <?php if($datas->status_id == 1): ?> 
                                        	<td>Approve</td>
                                        	<?php else: ?>
                                        	<td>Reject</td>
                                        	<?php endif; ?>
                                            <td><a href="#">Approve</a> | <a href="#">Reject</a></td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/auction/resources/views/dashboard/allusers.blade.php ENDPATH**/ ?>