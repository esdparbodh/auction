<?php $__env->startSection('title', 'ArtDeal'); ?>
<?php $__env->startSection('singleAuction'); ?>
<!-- breadcrumb start  -->
    <div class="breadcrumb-area">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="breadcrumb-inner d-flex justify-content-between">
                        <h2 class="page-title">Online Auction of Arts & Collectibles</h2>
                        <ul class="page-list">
                            <li><a href="index.html">Download Catalogue</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- breadcrumb end  -->
    
    <?php if(count($data) >= 1): ?>
    <!-- about content start  -->
    <div class="about-content margin-top-50">
        <div class="container">
            <div class="row">
                <div class="col-lg-5">
                    <div class="content-left">
                        <h5><b><?php echo e(date_format(date_create($data[0]->start_date),"d M")); ?> - 
	                        <?php echo e(date_format(date_create($data[0]->end_date),"d M Y")); ?> </b>
	                    </h5>
                        <?php echo $data[0]->art_description; ?>

                    </div>
                </div>
                <div class="col-lg-7">
                    <div class="thumb">
                        <img height="500" width="670" src="public/images/bigimage/<?php echo e($data[0]->big_image); ?>" alt="">
                        </div>
                </div>
            </div>
        </div>
    </div>
    <!-- about content end  -->
    
    
    <!-- artwork area start  -->
    <div class="tranding-area margin-top-20">
        <div class="container">
           <div class="tab-content">
                <div class="tab-pane fade in show active" id="one">
                    <div class="row">
                    	<?php for($i=0;$i<count(json_decode($data[0]->images));$i++): ?>
                        <div class="col-lg-4 col-md-6 col-sm-6 col-12">
                            <div class="product-style-02 margin-top-40">
                                <div class="thumb">
                                    <a href="live-auction-blowup.html"><img src="public/images/auctionDetails/<?php echo e((json_decode($data[0]->images))[$i]); ?>" alt=""></a>
                                    <span class="new">LOT 1</span>
                                    </div>
                                <div class="article-style-p">
			                        <div class="content">
			                            <h3><a href="#"><?php echo e(ucfirst($data[0]->title)); ?></a></h3>
			                            <p><?php echo e($data[0]->year); ?></p>
			                            <h6>₹ <?php echo e($data[0]->price_start); ?> - ₹ <?php echo e($data[0]->price_upto); ?></h6>
			                            <div class="btn-wrapper">
			                                <a href="live-auction-blowup.html" class="btn-bid btn-white">PLACE BID <i class="icon-arrow-buttom"></i></a>
			                            </div>
			                        </div>
			                    </div>
                            </div>
                        </div>
                        <?php endfor; ?>
                        
                    </div>
                </div>
             </div>
        </div>
    </div>
    <?php else: ?>
    <h3 style="text-align: center;padding: 20px;">Art details not Added.</h3>
    <?php endif; ?>
    <!-- artwork area end  -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/auction/resources/views/singleAuction.blade.php ENDPATH**/ ?>