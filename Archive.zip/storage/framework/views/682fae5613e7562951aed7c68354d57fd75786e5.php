<?php $__env->startSection('title', 'Departments'); ?>
<?php $__env->startSection('department'); ?>
<!-- breadcrumb start  -->
    <div class="breadcrumb-areablack">
        <div class="container">
            <div class="row">
                <div class="col-md-12"></div>
            </div>
        </div>
    </div>
    <!-- breadcrumb end  -->
    

    <!-- article area start  -->
    <div class="article-area margin-top-50">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="section-title-02 margin-bottom-30 text-center">
                        <h3>DEPARTMENTS</h3>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-4 col-md-6 col-sm-6 col-12">
                    <div class="article-style-01a">
                        <div class="content">
                            <h3><u>0-9</u></h3>
                            <div class="btn-wrapper">
                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	                            	<?php $FirstLetter = ucfirst(substr($datas->title, 0, 1)) ?>
	                            	<?php if(is_numeric($FirstLetter)): ?>
	                            	<a href="#" class="btn-bid btn-white"><?php echo e($datas->title); ?></a><br>
	                            	<?php endif; ?>
                            	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-sm-6 col-12">
                    <div class="article-style-01a">
                        <div class="content">
                            <h3><u>A</u></h3>
                            <div class="btn-wrapper">
                            	<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	                            	<?php $FirstLetter = ucfirst(substr($datas->title, 0, 1)) ?>
	                            	<?php if($FirstLetter == "A"): ?>
	                            	<a href="#" class="btn-bid btn-white"><?php echo e($datas->title); ?></a><br>
	                            	<?php endif; ?>
                            	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-sm-6 col-12">
                    <div class="article-style-01a">
                        <div class="content">
                            <h3><u>B</u></h3>
                            <div class="btn-wrapper">
                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	                            	<?php $FirstLetter = ucfirst(substr($datas->title, 0, 1)) ?>
	                            	<?php if($FirstLetter == "B"): ?>
	                            	<a href="#" class="btn-bid btn-white"><?php echo e(ucfirst($datas->title)); ?></a><br>
	                            	<?php endif; ?>
                            	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-sm-6 col-12">
                    <div class="article-style-01a">
                        <div class="content">
                            <h3><u>C</u></h3>
                            <div class="btn-wrapper">
                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	                            	<?php $FirstLetter = ucfirst(substr($datas->title, 0, 1)) ?>
	                            	<?php if($FirstLetter == "C"): ?>
	                            	<a href="#" class="btn-bid btn-white"><?php echo e(ucfirst($datas->title)); ?></a><br>
	                            	<?php endif; ?>
                            	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-sm-6 col-12">
                    <div class="article-style-01a">
                        <div class="content">
                            <h3><u>D</u></h3>
                            <div class="btn-wrapper">
                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	                            	<?php $FirstLetter = ucfirst(substr($datas->title, 0, 1)) ?>
	                            	<?php if($FirstLetter == "D"): ?>
	                            	<a href="#" class="btn-bid btn-white"><?php echo e(ucfirst($datas->title)); ?></a><br>
	                            	<?php endif; ?>
                            	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-sm-6 col-12">
                    <div class="article-style-01a">
                        <div class="content">
                            <h3><u>E</u></h3>
                            <div class="btn-wrapper">
                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	                            	<?php $FirstLetter = ucfirst(substr($datas->title, 0, 1)) ?>
	                            	<?php if($FirstLetter == "E"): ?>
	                            	<a href="#" class="btn-bid btn-white"><?php echo e(ucfirst($datas->title)); ?></a><br>
	                            	<?php endif; ?>
                            	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-sm-6 col-12">
                    <div class="article-style-01a">
                        <div class="content">
                            <h3><u>F</u></h3>
                            <div class="btn-wrapper">
                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	                            	<?php $FirstLetter = ucfirst(substr($datas->title, 0, 1)) ?>
	                            	<?php if($FirstLetter == "F"): ?>
	                            	<a href="#" class="btn-bid btn-white"><?php echo e(ucfirst($datas->title)); ?></a><br>
	                            	<?php endif; ?>
                            	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-sm-6 col-12">
                    <div class="article-style-01a">
                        <div class="content">
                            <h3><u>G</u></h3>
                            <div class="btn-wrapper">
                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	                            	<?php $FirstLetter = ucfirst(substr($datas->title, 0, 1)) ?>
	                            	<?php if($FirstLetter == "G"): ?>
	                            	<a href="#" class="btn-bid btn-white"><?php echo e(ucfirst($datas->title)); ?></a><br>
	                            	<?php endif; ?>
                            	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-sm-6 col-12">
                    <div class="article-style-01a">
                        <div class="content">
                            <h3><u>H</u></h3>
                            <div class="btn-wrapper">
                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	                            	<?php $FirstLetter = ucfirst(substr($datas->title, 0, 1)) ?>
	                            	<?php if($FirstLetter == "H"): ?>
	                            	<a href="#" class="btn-bid btn-white"><?php echo e(ucfirst($datas->title)); ?></a><br>
	                            	<?php endif; ?>
                            	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-sm-6 col-12">
                    <div class="article-style-01a">
                        <div class="content">
                            <h3><u>I</u></h3>
                            <div class="btn-wrapper">
                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	                            	<?php $FirstLetter = ucfirst(substr($datas->title, 0, 1)) ?>
	                            	<?php if($FirstLetter == "I"): ?>
	                            	<a href="#" class="btn-bid btn-white"><?php echo e(ucfirst($datas->title)); ?></a><br>
	                            	<?php endif; ?>
                            	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-sm-6 col-12">
                    <div class="article-style-01a">
                        <div class="content">
                            <h3><u>J</u></h3>
                            <div class="btn-wrapper">
                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	                            	<?php $FirstLetter = ucfirst(substr($datas->title, 0, 1)) ?>
	                            	<?php if($FirstLetter == "J"): ?>
	                            	<a href="#" class="btn-bid btn-white"><?php echo e(ucfirst($datas->title)); ?></a><br>
	                            	<?php endif; ?>
                            	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-sm-6 col-12">
                    <div class="article-style-01a">
                        <div class="content">
                            <h3><u>K</u></h3>
                            <div class="btn-wrapper">
                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	                            	<?php $FirstLetter = ucfirst(substr($datas->title, 0, 1)) ?>
	                            	<?php if($FirstLetter == "K"): ?>
	                            	<a href="#" class="btn-bid btn-white"><?php echo e(ucfirst($datas->title)); ?></a><br>
	                            	<?php endif; ?>
                            	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-sm-6 col-12">
                    <div class="article-style-01a">
                        <div class="content">
                            <h3><u>L</u></h3>
                            <div class="btn-wrapper">
                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	                            	<?php $FirstLetter = ucfirst(substr($datas->title, 0, 1)) ?>
	                            	<?php if($FirstLetter == "L"): ?>
	                            	<a href="#" class="btn-bid btn-white"><?php echo e(ucfirst($datas->title)); ?></a><br>
	                            	<?php endif; ?>
                            	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-sm-6 col-12">
                    <div class="article-style-01a">
                        <div class="content">
                            <h3><u>M</u></h3>
                            <div class="btn-wrapper">
                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	                            	<?php $FirstLetter = ucfirst(substr($datas->title, 0, 1)) ?>
	                            	<?php if($FirstLetter == "M"): ?>
	                            	<a href="#" class="btn-bid btn-white"><?php echo e(ucfirst($datas->title)); ?></a><br>
	                            	<?php endif; ?>
                            	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-sm-6 col-12">
                    <div class="article-style-01a">
                        <div class="content">
                            <h3><u>N</u></h3>
                            <div class="btn-wrapper">
                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	                            	<?php $FirstLetter = ucfirst(substr($datas->title, 0, 1)) ?>
	                            	<?php if($FirstLetter == "N"): ?>
	                            	<a href="#" class="btn-bid btn-white"><?php echo e(ucfirst($datas->title)); ?></a><br>
	                            	<?php endif; ?>
                            	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-sm-6 col-12">
                    <div class="article-style-01a">
                        <div class="content">
                            <h3><u>O</u></h3>
                            <div class="btn-wrapper">
                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	                            	<?php $FirstLetter = ucfirst(substr($datas->title, 0, 1)) ?>
	                            	<?php if($FirstLetter == "O"): ?>
	                            	<a href="#" class="btn-bid btn-white"><?php echo e(ucfirst($datas->title)); ?></a><br>
	                            	<?php endif; ?>
                            	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-sm-6 col-12">
                    <div class="article-style-01a">
                        <div class="content">
                            <h3><u>P</u></h3>
                            <div class="btn-wrapper">
                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	                            	<?php $FirstLetter = ucfirst(substr($datas->title, 0, 1)) ?>
	                            	<?php if($FirstLetter == "P"): ?>
	                            	<a href="#" class="btn-bid btn-white"><?php echo e(ucfirst($datas->title)); ?></a><br>
	                            	<?php endif; ?>
                            	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-sm-6 col-12">
                    <div class="article-style-01a">
                        <div class="content">
                            <h3><u>Q</u></h3>
                            <div class="btn-wrapper">
                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	                            	<?php $FirstLetter = ucfirst(substr($datas->title, 0, 1)) ?>
	                            	<?php if($FirstLetter == "Q"): ?>
	                            	<a href="#" class="btn-bid btn-white"><?php echo e(ucfirst($datas->title)); ?></a><br>
	                            	<?php endif; ?>
                            	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-sm-6 col-12">
                    <div class="article-style-01a">
                        <div class="content">
                            <h3><u>R</u></h3>
                            <div class="btn-wrapper">
                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	                            	<?php $FirstLetter = ucfirst(substr($datas->title, 0, 1)) ?>
	                            	<?php if($FirstLetter == "R"): ?>
	                            	<a href="#" class="btn-bid btn-white"><?php echo e(ucfirst($datas->title)); ?></a><br>
	                            	<?php endif; ?>
                            	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-sm-6 col-12">
                    <div class="article-style-01a">
                        <div class="content">
                            <h3><u>S</u></h3>
                            <div class="btn-wrapper">
                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	                            	<?php $FirstLetter = ucfirst(substr($datas->title, 0, 1)) ?>
	                            	<?php if($FirstLetter == "S"): ?>
	                            	<a href="#" class="btn-bid btn-white"><?php echo e(ucfirst($datas->title)); ?></a><br>
	                            	<?php endif; ?>
                            	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-sm-6 col-12">
                    <div class="article-style-01a">
                        <div class="content">
                            <h3><u>T</u></h3>
                            <div class="btn-wrapper">
                            	<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	                            	<?php $FirstLetter = ucfirst(substr($datas->title, 0, 1)) ?>
	                            	<?php if($FirstLetter == "T"): ?>
	                            	<a href="#" class="btn-bid btn-white"><?php echo e(ucfirst($datas->title)); ?></a><br>
	                            	<?php endif; ?>
                            	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-sm-6 col-12">
                    <div class="article-style-01a">
                        <div class="content">
                            <h3><u>U</u></h3>
                            <div class="btn-wrapper">
                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	                            	<?php $FirstLetter = ucfirst(substr($datas->title, 0, 1)) ?>
	                            	<?php if($FirstLetter == "U"): ?>
	                            	<a href="#" class="btn-bid btn-white"><?php echo e(ucfirst($datas->title)); ?></a><br>
	                            	<?php endif; ?>
                            	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-sm-6 col-12">
                    <div class="article-style-01a">
                        <div class="content">
                            <h3><u>V</u></h3>
                            <div class="btn-wrapper">
                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	                            	<?php $FirstLetter = ucfirst(substr($datas->title, 0, 1)) ?>
	                            	<?php if($FirstLetter == "V"): ?>
	                            	<a href="#" class="btn-bid btn-white"><?php echo e(ucfirst($datas->title)); ?></a><br>
	                            	<?php endif; ?>
                            	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-sm-6 col-12">
                    <div class="article-style-01a">
                        <div class="content">
                            <h3><u>W</u></h3>
                            <div class="btn-wrapper">
                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	                            	<?php $FirstLetter = ucfirst(substr($datas->title, 0, 1)) ?>
	                            	<?php if($FirstLetter == "W"): ?>
	                            	<a href="#" class="btn-bid btn-white"><?php echo e(ucfirst($datas->title)); ?></a><br>
	                            	<?php endif; ?>
                            	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-sm-6 col-12">
                    <div class="article-style-01a">
                        <div class="content">
                            <h3><u>X</u></h3>
                            <div class="btn-wrapper">
                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	                            	<?php $FirstLetter = ucfirst(substr($datas->title, 0, 1)) ?>
	                            	<?php if($FirstLetter == "X"): ?>
	                            	<a href="#" class="btn-bid btn-white"><?php echo e(ucfirst($datas->title)); ?></a><br>
	                            	<?php endif; ?>
                            	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-sm-6 col-12">
                    <div class="article-style-01a">
                        <div class="content">
                            <h3><u>Y</u></h3>
                            <div class="btn-wrapper">
                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	                            	<?php $FirstLetter = ucfirst(substr($datas->title, 0, 1)) ?>
	                            	<?php if($FirstLetter == "Y"): ?>
	                            	<a href="#" class="btn-bid btn-white"><?php echo e(ucfirst($datas->title)); ?></a><br>
	                            	<?php endif; ?>
                            	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="col-lg-4 col-md-6 col-sm-6 col-12">
                    <div class="article-style-01a">
                        <div class="content">
                            <h3><u>Z</u></h3>
                            <div class="btn-wrapper">
                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	                            	<?php $FirstLetter = ucfirst(substr($datas->title, 0, 1)) ?>
	                            	<?php if($FirstLetter == "Z"): ?>
	                            	<a href="#" class="btn-bid btn-white"><?php echo e(ucfirst($datas->title)); ?></a><br>
	                            	<?php endif; ?>
                            	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- article area end  -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/auction/resources/views/department.blade.php ENDPATH**/ ?>