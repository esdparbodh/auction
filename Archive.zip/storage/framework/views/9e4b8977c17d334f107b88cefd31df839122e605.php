<?php $__env->startSection('title', 'Login'); ?>
<?php $__env->startSection('login'); ?>
<!-- breadcrumb start  -->
    <div class="breadcrumb-areablack">
        <div class="container">
            <div class="row">
                <div class="col-md-12"></div>
            </div>
        </div>
    </div>
    <!-- breadcrumb end  -->
    
    <?php if(Request::is('admin/login')): ?>
    <?php  ?>
    <!-- article area start  -->
    <div class="article-area margin-top-50">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="section-title-02 margin-bottom-10 text-center">
                        <h3>Admin Login </h3>
                    </div>
                </div>
            </div>
         </div>
    </div>
    <?php else: ?>
    <div class="article-area margin-top-50">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="section-title-02 margin-bottom-10 text-center">
                        <h3>MY ARTDEAL ACCOUNT</h3>
                        <h6>New to ARTDEAL?&nbsp;&nbsp;&nbsp;<a href="<?php echo e(route('registration')); ?>" class="color-main">JOIN</a></h6>
                    </div>
                </div>
            </div>
         </div>
    </div>
    <?php endif; ?>
    <!-- article area end  -->
    
    <!-- contact area start  -->
    <div class="contact-area grey-bg margin-top-10">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-8">
                    <div class="contact-content-03 text-center padding-top-20 padding-bottom-50">
                        <?php if(session()->has('message')): ?>
                            <div class="alert alert-danger">
                                <?php echo e(session()->get('message')); ?>

                            </div>
                        <?php endif; ?>
                        <form method="POST" action="<?php echo e(route('login')); ?>">
                        	<?php echo e(csrf_field()); ?>

                            <?php if(Request::is('admin/login')): ?>
                            <input type="hidden" name="role" value="Admin">
                            <?php else: ?>
                            <input type="hidden" name="role" value="User">
                            <?php endif; ?>
                            <div class="form-row align-items-center justify-content-center">
                              <div class="col-10 col-sm-8">
                              <div class="input-group">
                                  <input type="text" class="form-control" id="inlineFormInputGroup" placeholder="Email Address" name="email">
                                </div>
                                <div class="input-group">
                                  <input type="text" class="form-control" id="inlineFormInputGroup" placeholder="Password" name="password">
                                </div>
                                <div class="btn-wrapper">
                                	<input type="submit" name="LOGIN" class="btn btn-yellow">
                                    
                                </div>
                              </div>
                            </div>
                        </form>
                        <!-- <h6><a href="registration.html" class="color-main">Forgot Password?</a></h6> -->
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- contact area end  -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/auction/resources/views/login.blade.php ENDPATH**/ ?>