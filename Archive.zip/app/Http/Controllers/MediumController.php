<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use Response;
use DB;
use App\Internreport;
use App\Feedback;
use PDF;
use Auth;
class MediumController extends Controller {
   public function viewdepartment()
   {
      $data=DB::table('departments')->get();
      return view('department')->with('data',$data);
   }
   public function index()
   {
      $data=DB::table('mediums')->get();
   	return view('dashboard.allMediums')->with('data',$data);
   }
   public function view()
   {
      return view('dashboard.addMedium');
   }
   public function add(Request $request)
   {
      $title = $request->input('title');
      $description = $request->input('editor1');
      $register = [
         'title'=> $title,
      ];
      $SaveQuery = DB::table('mediums')->insert($register);
      if($SaveQuery){
         return redirect()->back()->with('message', 'You have successfully Added Medium .');
      }else{
         return redirect()->back()->with('message', 'Medium not AddedRequest');
      }
   }
   public function delete(Request $request)
   {
      $id = $request->input('id');
      //return response($id);
      $SaveQuery = DB::table('mediums')->where('id', $id)->delete();
      if($SaveQuery){
         return redirect()->back()->with('message', 'You have successfully Delete Medium .');
      }else{
         return redirect()->back()->with('message', 'Medium not deleted.');
      }
   }
   public function edit($id)
   {
      $data=DB::table('mediums')->where('id',$id)->get();
      return view('dashboard.addMedium')->with('data',$data);
   }
   public function Update(Request $request)
   {
      $id = $request->input('id');
      $title = $request->input('title');
      $description = $request->input('editor1');
      $register = [
         'title'=> $title,
         'description'=>$description,
      ];
      $SaveQuery = DB::table('mediums')->where('id',$id)->update($register);
      if($SaveQuery){
         return redirect()->back()->with('message', 'You have successfully Update Medium .');
      }else{
         return redirect()->back()->with('message', 'Medium not Updated');
      }
   }
   

}