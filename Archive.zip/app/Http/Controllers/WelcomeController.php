<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use Response;
use DB;

class WelcomeController extends Controller {
   public function index()
   {
      $UpcomingAuctions = DB::table('auctions')
                       ->where('type','Upcoming')
                       ->take(3)
                       ->orderBy('id', 'DESC')
                       ->get();
      return view('welcome')->with(['UAuctions'=>$UpcomingAuctions]);
   }
   public function SingleAuction(Request $request)
   {
      $id = $request->id;
      $data =  DB::table('auction_details')
            ->select('auction_details.*','auctions.*')
            ->join('auctions','auctions.id','=','auction_details.auction_id')
             ->where(['auction_details.auction_id' => $id])
            ->get();
      //$data=DB::table('auction_details')->where('auction_id',$id)->get();
      //return response($data);
      return view('singleAuction')->with(['data'=>$data]);
   }
}