<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use Response;
use DB;
use App\Internreport;
use App\Feedback;
use PDF;
use Auth;
class SliderController extends Controller {
   public function index()
   {
      $data=DB::table('sliders')->get();
      return view('dashboard.allSliders')->with('data',$data);
   }
   public function addSlider()
   {
      return view('dashboard.addSlider');
   }
   public function viewdepartment()
   {
      $data=DB::table('departments')->get();
      return view('department')->with('data',$data);
   }
   
   
   public function add(Request $request)
   {
      $name = $request->input('name');
      $buttonName = $request->input('buttonName');

      $SliderImage = $request->file('image');
      $input['filenameImage'] = rand().$SliderImage->getClientOriginalName();
      $SliderimageDestinationPath = public_path('/images/slider/');
      $Slider_Image = $input['filenameImage'];
      $SliderImage->move($SliderimageDestinationPath, $input['filenameImage']);


      $register = [
         'name'=> $name,
         'button_name'=>$buttonName,
         'image'=>$Slider_Image
      ];
      $SaveQuery = DB::table('sliders')->insert($register);
      if($SaveQuery){
         return redirect()->back()->with('message', 'You have successfully Added Slider .');
      }else{
         return redirect()->back()->with('message', 'Slider not Added');
      }
   }
   public function delete(Request $request)
   {
      $id = $request->input('id');
      //return response($id);
      $SaveQuery = DB::table('departments')->where('id', $id)->delete();
      if($SaveQuery){
         return redirect()->back()->with('message', 'You have successfully Delete Department .');
      }else{
         return redirect()->back()->with('message', 'Department not deleted.');
      }
   }
   public function edit($id)
   {
      $data=DB::table('departments')->where('id',$id)->get();
      return view('dashboard.addDepartment')->with('data',$data);
   }
   public function Update(Request $request)
   {
      $id = $request->input('id');
      $title = $request->input('title');
      $description = $request->input('editor1');
      $register = [
         'title'=> $title,
         'description'=>$description,
      ];
      $SaveQuery = DB::table('departments')->where('id',$id)->update($register);
      if($SaveQuery){
         return redirect()->back()->with('message', 'You have successfully Update Department .');
      }else{
         return redirect()->back()->with('message', 'Department not Updated');
      }
   }
   

}