<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Input;
use Response;
use DB;
use PDF;
use Auth;
class ArtistController extends Controller {
   public function index()
   {
      $data=DB::table('artists')->get();
      return view('dashboard.allArtist')->with('data',$data); 
   }
   public function addArtistView(Request $request)
   {
      return view('dashboard.addArtist');
   }
   public function addartist(Request $request){
      $rules = array(
        "image" => 'required|mimes:jpeg,png,jpg,webp|max:1000',
        );

        $validator = Validator::make($request->all(), $rules);
        if ($validator->fails()) {
            return Redirect::back()
                ->withErrors($validator) // send back all errors to the login form
                ->withInput();

            $input = input::all();
         }else{
            $image = $request->file('image');
            $input['filename'] = $image->getClientOriginalName();
            $destinationPath = public_path('/images/artist/');
            $Artist_image = $input['filename'];
            $image->move($destinationPath, $input['filename']);


            $name = $request->input('name');
            $dob = $request->input('dob');
            $dod = $request->input('dod');
            $description = $request->input('editor1');
            $register = [
               'name'=> $name,
               'dob'=>$dob,
               'dob'=>$dob,
               'description'=>$description,
               'image'=>$Artist_image,
            ];
            $SaveQuery = DB::table('artists')->insert($register);
            if($SaveQuery){
               return redirect()->back()->with('message', 'You have successfully Added Artist.');
            }else{
               return redirect()->back()->with('message', 'Artist not added.');
            }
         }
   }
   public function DeleteArtist(Request $request)
   {
      $id = $request->input('id');
      //return response($id);
      $SaveQuery = DB::table('artists')->where('id', $id)->delete();
      if($SaveQuery){
         return redirect()->back()->with('message', 'You have successfully Delete Artist .');
      }else{
         return redirect()->back()->with('message', 'Artist not deleted.');
      }
   }
   public function editArtists($id)
   {
      $data=DB::table('artists')->where('id',$id)->get();
      return view('dashboard.addArtist')->with('data',$data);
   }
   public function Update(Request $request)
   {
      $rules = array(
        "image" => 'required|mimes:jpeg,png,jpg,webp|max:1000',
        );

        $validator = Validator::make($request->all(), $rules);
        if ($validator->fails()) {
            return Redirect::back()
                ->withErrors($validator) // send back all errors to the login form
                ->withInput();

            $input = input::all();
         }else{
            $id = $request->input('id');
            $image = $request->file('image');
            $input['filename'] = $image->getClientOriginalName();
            $destinationPath = public_path('/images/artist/');
            $Artist_image = $input['filename'];
            $image->move($destinationPath, $input['filename']);


            $name = $request->input('name');
            $dob = $request->input('dob');
            $dod = $request->input('dod');
            $description = $request->input('editor1');
            $register = [
               'name'=> $name,
               'dob'=>$dob,
               'dob'=>$dob,
               'description'=>$description,
               'image'=>$Artist_image,
            ];
            $SaveQuery = DB::table('artists')->where('id',$id)->update($register);
            if($SaveQuery){
               return redirect()->back()->with('message', 'You have successfully Update Artist.');
            }else{
               return redirect()->back()->with('message', 'Artist not Update.');
            }
         }
   }
   
   
}