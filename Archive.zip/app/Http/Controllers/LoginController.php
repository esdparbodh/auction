<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
// use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Input;
use Auth;
use DB;

class LoginController extends Controller
{
    /**
     * Handle an authentication attempt.
     *
     * @param  \Illuminate\Http\Request $request
     *
     * @return Response
     */
    // use AuthenticatesUsers;

    /**
     * Where to redirect users after login.
     *
     * @var string
     */
    protected $redirectTo = '/dashboard';
    
    // public function __construct()
    // {
    //     $this->middleware('guest')->except('logout');
    // }
    public function logout () {
        //logout user
        auth()->logout();
        // redirect to homepage
        return redirect('/');
    }
   
    public function index()
    {
        return view('login');
    }
    
    public function authenticate(Request $request)
    {
        $rules = array(
            "email"  => "required|email",
            "password"  => "required|min:3"
  
        );
        $validator = Validator::make($request->all(), $rules);
        if ($validator->fails()) {
            //return "13"; 
            return Redirect::back()
                ->withErrors($validator) // send back all errors to the login form
                ->withInput();

            $input = input::all();
         }else{
            if($request->role == 'Admin'){
                if (Auth::attempt(['email' => $request->email, 'password' => $request->password,'status_id' => 1,'role' => 'Admin'])) {
                    return redirect()->intended('/dashboard');
                }else{
                    return redirect()->back()->with('message', 'Invalid User.');
                }
            }else{
                if (Auth::attempt(['email' => $request->email, 'password' => $request->password,'status_id' => 1,'role' => 'User'])) {
                    return redirect()->intended('/');
                }else{
                    return redirect()->back()->with('message', 'Invalid User.');
                }
            }
            
         }
        
    }
    
}