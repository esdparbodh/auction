<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Input;
use Response;
use DB;
use PDF;
use Auth;
class NewsletterController extends Controller {
   public function index()
   {
      $data=DB::table('subscribes')->get();
      return view('dashboard.newsletter')->with('data',$data); 
   }
   public function addsubscriber(Request $request)
   {
      $rules = array(
         "email"=>"required|unique:subscribes",
      );
      $validator = Validator::make($request->all(), $rules);
        if ($validator->fails()) {
            return Redirect::back()
                ->withErrors($validator) // send back all errors to the login form
                ->withInput();

            $input = input::all();
       }else{
         $name = $request->input('name');
         $email = $request->input('email');
         $register = [
            'name'=> $name,
            'email'=>$email,
         ];
         $SaveQuery = DB::table('subscribes')->insert($register);
         if($SaveQuery){
            return redirect()->back()->with('message', 'You have successfully subscribe.');
         }else{
            return redirect()->back()->with('message', 'You are not Subscribe');
         }
      }
   }
   public function Unsubscribe($id)
   {
      DB::table('subscribes')->where('id',$id)->delete();
      $data=DB::table('subscribes')->get();
      return view('dashboard.newsletter')->with('data',$data);
   }
}