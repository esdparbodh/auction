<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use Response;
use DB;
use App\Internreport;
use App\Feedback;
use PDF;
use Auth;
class DepartmentController extends Controller {
   public function viewdepartment()
   {
      $data=DB::table('departments')->get();
      return view('department')->with('data',$data);
   }
   public function index()
   {
      $data=DB::table('departments')->get();
   	return view('dashboard.allDepartments')->with('data',$data);
   }
   public function view()
   {
      return view('dashboard.addDepartment');
   }
   public function add(Request $request)
   {
      $title = $request->input('title');
      $description = $request->input('editor1');
      $register = [
         'title'=> $title,
         'description'=>$description,
      ];
      $SaveQuery = DB::table('departments')->insert($register);
      if($SaveQuery){
         return redirect()->back()->with('message', 'You have successfully Added Department .');
      }else{
         return redirect()->back()->with('message', 'Department not AddedRequest');
      }
   }
   public function delete(Request $request)
   {
      $id = $request->input('id');
      //return response($id);
      $SaveQuery = DB::table('departments')->where('id', $id)->delete();
      if($SaveQuery){
         return redirect()->back()->with('message', 'You have successfully Delete Department .');
      }else{
         return redirect()->back()->with('message', 'Department not deleted.');
      }
   }
   public function edit($id)
   {
      $data=DB::table('departments')->where('id',$id)->get();
      return view('dashboard.addDepartment')->with('data',$data);
   }
   public function Update(Request $request)
   {
      $id = $request->input('id');
      $title = $request->input('title');
      $description = $request->input('editor1');
      $register = [
         'title'=> $title,
         'description'=>$description,
      ];
      $SaveQuery = DB::table('departments')->where('id',$id)->update($register);
      if($SaveQuery){
         return redirect()->back()->with('message', 'You have successfully Update Department .');
      }else{
         return redirect()->back()->with('message', 'Department not Updated');
      }
   }
   

}