<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Input;
use Response;
use DB;
use PDF;
use Auth;
class AuctionController extends Controller {
   public function index()
   {
      $data=DB::table('auctions')->get();
      return view('dashboard.allAuctions')->with('data',$data);
   }
   public function view()
   {
      $data=DB::table('departments')->get();
      return view('dashboard.addAuction')->with('data',$data);
   }
   public function AddAuction(Request $request){
      $rules = array(
        "cataloge_pdf" => 'required|mimes:pdf|max:2000',
        "big_image" => 'required|mimes:jpeg,png,jpg,webp|max:1000',
        );

        $validator = Validator::make($request->all(), $rules);
        if ($validator->fails()) {
            return Redirect::back()
                ->withErrors($validator) // send back all errors to the login form
                ->withInput();

            $input = input::all();
         }else{
            $catPDF = $request->file('cataloge_pdf');
            $input['pdffilename'] = rand().$catPDF->getClientOriginalName();
            $PDFdestinationPath = public_path('/documents/cataloge/');
            $CatalogePDF = $input['pdffilename'];
            $catPDF->move($PDFdestinationPath, $input['pdffilename']);

            $BigImage = $request->file('big_image');
            $input['filenameBigImage'] = rand().$BigImage->getClientOriginalName();
            $BigimageDestinationPath = public_path('/images/bigimage/');
            $Big_Image = $input['filenameBigImage'];
            $BigImage->move($BigimageDestinationPath, $input['filenameBigImage']);

            if($request->hasfile('thumbnail_image'))
            {
               foreach($request->file('thumbnail_image') as $image_thumb)
               {
                  $thumBnailIMG=rand().$image_thumb->getClientOriginalName();
                  $image_thumb->move(public_path().'/images/thumbnailImage/', $thumBnailIMG);  
                  $data[] = $thumBnailIMG;  
               }
            }else
            {
               $data = null;
            }



            $title = $request->input('title');
            $type = $request->input('type');
            $startDate = $request->input('start_date');
            $endDate = $request->input('end_date');
            $description = $request->input('editor1');
            $Department = $request->input('department');
            $AuctION = [
               'title'=> $title,
               'department'=>$Department,
               'type'=> $type,
               'start_date'=>$startDate,
               'end_date'=>$endDate,
               'description'=>$description,
               'cataloge_pdf'=>$CatalogePDF,
               'big_image'=>$Big_Image,
               'thumbnail_image'=>json_encode($data)
            ];
            $SaveQuery = DB::table('auctions')->insert($AuctION);
            if($SaveQuery){
               return redirect()->back()->with('message', 'You have successfully Added Auction.');
            }else{
               return redirect()->back()->with('message', 'Auction not added.');
            }
         }
   }
   public function AuctionDetails()
   {
      $data3=DB::table('departments')->get();
      $data=DB::table('artists')->select('name')->get();
      $data2=DB::table('mediums')->select('title')->get();
      return view('dashboard.auctionDetails')->with(
         [
            'data'=>$data,
            'data2'=>$data2,
            'data3'=>$data3
         ]);
   }
   public function AddActionDetails(Request $request){
      if($request->hasfile('images'))
            {
               foreach($request->file('images') as $image_thumb)
               {
                  $thumBnailIMG=rand().$image_thumb->getClientOriginalName();
                  $image_thumb->move(public_path().'/images/auctionDetails/', $thumBnailIMG);  
                  $data[] = $thumBnailIMG;  
               }
            }else
            {
               $data = null;
            }

            $Department = $request->input('department');
            $title = $request->input('title');
            $ArtType = $request->input('ArtType');
            $Auction = $request->input('Auction');
            $AuctionType = $request->input('AuctionType');            
            $artist = $request->input('artist');
            $lot = $request->input('lot');
            $code = $request->input('code');
            $year = $request->input('year');
            $medium = $request->input('medium');
            $height = $request->input('height');
            $width = $request->input('width');
            $depth = $request->input('depth');
            $price_start = $request->input('price_start');
            $price_upto = $request->input('price_upto');
            $description = $request->input('editor1');
            $AuctION = [
               'title'=>$title,
               'department'=>$Department,
               'art_type'=>$ArtType,
               'auction'=>$Auction,
               'auction_type'=> $AuctionType,
               'artist'=> $artist,
               'lot'=>$lot,
               'code'=>$code,
               'year'=>$year,
               'medium'=>$medium,
               'size_h'=>$height,
               'size_w'=>$width,
               'size_d'=>$depth,
               'price_start'=>$price_start,
               'price_upto'=>$price_upto,
               'images'=>json_encode($data),
               'art_description'=>$description,
            ];
            $SaveQuery = DB::table('auction_details')->insert($AuctION);
            if($SaveQuery){
               return redirect()->back()->with('message', 'You have successfully Added Auction details.');
            }else{
               return redirect()->back()->with('message', 'Auction Details not added.');
            }
   }
   public function GetAuctions(Request $request)
   {
      $type = $request->input('AuctionType');
      $data3=DB::table('auctions')->select('title')->where('type',$type)->get();
      return response($data3);
   }
   public function AllArts()
   {
      $data=DB::table('auction_details')->get();
      return view('dashboard.allArts')->with('data',$data);
   }
   public function UploadArtImages($id)
   {
      $data=DB::table('auction_details')->where('id',$id)->get();
      return view('dashboard.uploadArtimages')->with('data',$data);
   }
   public function AddImagesArt(Request $request)
   {
      // return response($request->file('image'));
      $id = $request->input('id');
      $type = $request->input('selectImageType');
      if($type == 'Thumbnail'){
         if($request->hasfile('image'))
            {
               foreach($request->file('image') as $image_thumb)
               {
                  $thumBnailIMG=rand().$image_thumb->getClientOriginalName();
                  $image_thumb->move(public_path().'/images/auctionDetails/', $thumBnailIMG);  
                  $data[] = $thumBnailIMG;  
               }
            }else
            {
               $data = null;
            }
         
         $AuctION = [
            'images'=> json_encode($data),
         ];
      }else{
         $ArtImage = $request->file('image');
         $input['filenameArtImage'] = rand().$ArtImage->getClientOriginalName();
         $ArtImageDestinationPath = public_path('/images/auctionDetails/');
         $data = $input['filenameArtImage'];
         $ArtImage->move($ArtImageDestinationPath, $input['filenameArtImage']);

         if($type == "Big Image"){
            $AuctION = [
               'big_image'=>json_encode($data)
            ];
         }elseif($type == 'Blowup 1'){
            $AuctION = [
               'b1'=>$data
            ];
         }elseif($type == 'Blowup 2'){
            $AuctION = [
               'b2'=>$data
            ];
         }elseif($type == 'Blowup 3'){
            $AuctION = [
               'b3'=>$data
            ];
         }else{
            $AuctION = [
               'b4'=>$data
            ];
         }
         
      }
      

      $SaveQuery = DB::table('auction_details')->where('id',$id)->update($AuctION);
      if($SaveQuery){
         return redirect()->back()->with('message', 'You have successfully Added Image.');
      }else{
         return redirect()->back()->with('message', 'Image not added.');
      }
      
   }
}