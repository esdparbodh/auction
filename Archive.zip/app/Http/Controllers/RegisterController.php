<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Input;
use DB;
use App\User;
class RegisterController extends Controller {
   public function signup($value='')
   {
      return view('registration');
   }
   public function index(Request $request)
   {
      $rules = array(
         "email"=>"required|unique:users",
         "mobile" => "required|string|min:10|max:10|unique:users",
      );
      $validator = Validator::make(Input::all(), $rules);
        if ($validator->fails()) {
            return Redirect::back()
                ->withErrors($validator) // send back all errors to the login form
                ->withInput();

            $input = input::all();
       }else{
         $PWord = $request->input('password');
         $CPword = $request->input('cpassword');
         if($PWord == $CPword){
            $name = $request->input('name');
            $email = $request->input('email');
            $mobile = $request->input('mobile');
            $password = $CPword;
            $houseAddress = $request->input('house_address');
            $streetAreaAddress = $request->input('street_area_address');
            $country = $request->input('country');
            $city = $request->input('city');
            $state = $request->input('state');
            $pincode = $request->input('pincode');
            $role = 'User';
           
            $register = [
               'name'=> $name,
               'email'=>$email,
               'mobile'=>$mobile,
               'password'=>bcrypt($password),
               'house_address'=>$houseAddress,
               'street_area_address'=>$streetAreaAddress,
               'city'=>$city,
               'country'=>$country,
               'state'=>$state,
               'pincode'=>$pincode,
               'role'=>$role,
               
            ];
            $SaveQuery = DB::table('users')->insert($register);
            if($SaveQuery){
               return redirect()->back()->with('message', 'You have successfully registered .');
            }else{
               return redirect()->back()->with('message', 'Account not created');
            }
         }else{
            return redirect()->back()->with('message', 'Password not matched');
         }
       }
      
   }
   public function ViewStudentDetails(Request $request)
   {
      $id = $request->input('id');
      
      $data = DB::table('users')->where('id',$id)->get();
      return view('studentDetails')->with('data',$data);
   }
}