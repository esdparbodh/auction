<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use Response;
use DB;
use PDF;
use Auth;
class UserController extends Controller {
   public function index()
   {
   	// $data = DB::table('users')->where('status_id',0)->get();
      // return view('dashboard')->with('data',$data);
      $ROle = Auth::user()->role;
       
      if($ROle == 'Admin'){
         return view('dashboard.dashboard');
      }else{
         return view('welcome');
      }
      
   }
   public function AllUsers()
   {
      $data=DB::table('users')->get();
      return view('dashboard.allusers')->with('data',$data);
   }
   public function completeintern()
   {
   		$data = DB::table('users')->where('status_id',0)->get();
        return view('dashboard')->with('data',$data);
   }
   public function ApproveRegis(Request $request)
   {
   	$id = $request->input('id');
      $letterno = $request->input('letterno');
      $date = $request->input('date');
      // return response($letterno);
   	DB::table('users')->where('id',$id)->update([
         'status_id'=>1,
         'accept_letter_no'=>$letterno,
         'accept_date'=>$date
      ]);

   	$data['statuscode'] = "TXN";
	   $data['message'] = "Student Approved.";
	    return response($data);	
   }
   public function SubmitReport(Request $request)
   {
      $name = $request->input('name');
      $college = $request->input('college');
      $university = $request->input('university');
      $internship = $request->input('internship');
      $email = $request->input('email');

      $workReport = $request->file('workReport');
      $input['workReport'] = uniqid() .$workReport->getClientOriginalName();
      $destinationPath = public_path('/reports/work/');
      $workReport_fileName = $input['workReport'];
      $workReport->move($destinationPath, $input['workReport']);

      $supervReport = $request->file('supervReport');
      $input['supervReport'] = uniqid() .$supervReport->getClientOriginalName();
      $destinationPath = public_path('/reports/superviser/');
      $supervReport_fileName = $input['supervReport'];
      $supervReport->move($destinationPath, $input['supervReport']);

      $perforReport = $request->file('perforReport');
      $input['perforReport'] = uniqid() .$perforReport->getClientOriginalName();
      $destinationPath = public_path('/reports/performance/');
      $perforReport_fileName = $input['perforReport'];
      $perforReport->move($destinationPath, $input['perforReport']);

      $register = [
         'name'=> $name,
         'college'=>$college,
         'university'=>$university,
         'internship'=>$internship,
         'email'=>$email,
         'work_report'=>$workReport_fileName,
         'super_report'=>$supervReport_fileName,
         'perform_report'=>$perforReport_fileName
        
      ];
         $SaveQuery = DB::table('internreports')->insert($register);
         if($SaveQuery){
            return redirect()->back()->with('message', 'Application Submitted Successfully.');
         }else{
            return redirect()->back()->with('message', 'data not saved');
         }
   }
   public function viewDocUser($type,$filename)
   {
      switch ($type) {
         case 'id_proof_file':
            $file_path = public_path('/images/idprooffile/'.$filename);
            return response()->download($file_path);
            break;
         case 'inter_file':
            $file_path = public_path('/images/internfile/'.$filename);
            return response()->download($file_path);
            break;
         case 'resume_file':
            $file_path = public_path('/images/resumefile/'.$filename);
            return response()->download($file_path);
            break;
         
         default:
            
            break;
      }
   }
   public function pendingCRequest()
   {
      $data = DB::table('internreports')->where('status_id',0)->get();
      return view('pendingRegisteration')->with('data',$data);
   }
   public function CompletionRequest(Request $request)
   {
      $id = $request->input('id');
      $data = DB::table('internreports')->where('id',$id)->get();
      return view('completionReq')->with('data',$data);
   }
   public function DownloadReport($type,$filename)
   {
      //return response($type);
      switch ($type) {
         case 'Performance':
            $file_path = public_path('/reports/performance/'.$filename);
            return response()->download($file_path);
            break;
         case 'Supervisor':
            $file_path = public_path('/reports/superviser/'.$filename);
            return response()->download($file_path);
            break;
         case 'Work':
            $file_path = public_path('/reports/work/'.$filename);
            return response()->download($file_path);
            break;
         
         default:
            
            break;
      }
   }
   public function ApproveCompRequest(Request $request)
   {
      $id = $request->input('id');
      DB::table('internreports')->where('id',$id)->update([
         'status_id'=>1,
      ]);

      $data['statuscode'] = "TXN";
      $data['message'] = "Student Approved.";
      return response($data);
   }
   public function pdfview($id)
   {
      $products = DB::table('internreports')->where('id',$id)->get();
      view()->share('products',$products);
      $pdf = PDF::loadView('test');
      return $pdf->download('report.pdf');
   }
   public function FeedbackSubmit(Request $request)
   {
      $email = $request->input('email');
      $superviser = $request->input('superviser');
      $workflow = $request->input('workflow');
      $deveSkill = $request->input('deveSkill');
      $orgProcess = $request->input('orgProcess');
      $interskill = $request->input('interskill');
      $careerGoal = $request->input('careerGoal');
      $practImpli = $request->input('practImpli');
      $internBenefit = $request->input('internBenefit');
      $internSigni = $request->input('internSigni');
      $dislikeIntern = $request->input('dislikeIntern');
      $workExperience = $request->input('workExperience');
      $internSuggest = $request->input('internSuggest');
      $date = $request->input('date');
      
      $data=[
         'email'=>$email,
         'superviser'=>$superviser,
         'workflow'=>$workflow,
         'deveSkill'=>$deveSkill,
         'orgProcess'=>$orgProcess,
         'interskill'=>$interskill,
         'careerGoal'=>$careerGoal,
         'practImpli'=>$practImpli,
         'internBenefit'=>$internBenefit,
         'internSigni'=>$internSigni,
         'dislikeIntern'=>$dislikeIntern,
         'workExperience'=>$workExperience,
         'internSuggest'=>$internSuggest,
         'date'=>$date
      ];
      DB::table('feedbacks')->insert($data);
      DB::table('users')->where('email',$email)->update(['feedback_status'=>1]);
      return back();
   }
}