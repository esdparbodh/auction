<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/



Route::get('/','WelcomeController@index')->name('/');
Route::get('singleAuction.{id}','WelcomeController@SingleAuction');




Route::get('login','LoginController@index')->name('login');
Route::get('admin/login','LoginController@index');
Route::get('registration','RegisterController@signup')->name('registration');
Route::post('register','RegisterController@index')->name('register');
Route::post('login','LoginController@authenticate')->name('login');

Route::get('department','DepartmentController@viewdepartment')->name('department');

Route::get('newsletter','NewsletterController@index')->name('newsletter');
Route::post('subscribeme','NewsletterController@addsubscriber')->name('subscribeme');


Route::middleware(['auth'])->group(function () 
{
    Route::get('allSliders','SliderController@index')->name('allSliders');
    Route::get('addSlider','SliderController@addSlider')->name('addSlider');
    Route::post('addSlider','SliderController@add')->name('addSlider');


    Route::get('/logout','LoginController@logout')->name('logout');
    Route::get('dashboard','UserController@index')->name('dashboard');
    Route::get('allUsers','UserController@AllUsers')->name('allUsers');

    Route::get('addDepartments','DepartmentController@view')->name('addDepartments');
    Route::get('editDepartments.{id}','DepartmentController@edit')->name('editDepartments');
    Route::post('addDepartment','DepartmentController@add')->name('addDepartment');
    Route::post('deleteDepartment','DepartmentController@delete')->name('deleteDepartment');
    Route::post('editDepartment','DepartmentController@Update')->name('editDepartment');
    Route::get('allDepartments','DepartmentController@index')->name('allDepartments');

    Route::get('unsubscribe.{id}','NewsletterController@Unsubscribe')->name('unsubscribe');

    Route::get('allArtists','ArtistController@index')->name('allArtists');
    Route::get('addArtist','ArtistController@addArtistView')->name('addArtist');
    Route::post('AddArtist','ArtistController@addartist')->name('AddArtist');
    Route::post('deleteArtist','ArtistController@DeleteArtist')->name('deleteArtist');
    Route::get('editArtists.{id}','ArtistController@editArtists')->name('editArtists');
    Route::post('editArtist','ArtistController@Update')->name('editArtist');
    
    
    Route::get('allAuctions','AuctionController@index')->name('allAuctions');
    Route::get('addAuction','AuctionController@view')->name('addAuction');
    Route::post('addAuction','AuctionController@AddAuction')->name('addAuction');
    Route::get('auctionDetails','AuctionController@AuctionDetails')->name('auctionDetails');
    Route::post('addActionDetails','AuctionController@AddActionDetails')->name('addActionDetails');
    Route::post('getauctions','AuctionController@GetAuctions')->name('getauctions');
    Route::get('allArts','AuctionController@AllArts')->name('allArts');
    Route::get('uploadArtImages.{id}','AuctionController@UploadArtImages')->name('uploadArtImages');
    Route::post('addImagesArt','AuctionController@AddImagesArt')->name('addImagesArt');
    


    Route::get('allMediums','MediumController@index')->name('allMediums');
    Route::get('addMediums','MediumController@view')->name('addMediums');
    Route::get('editMediums.{id}','MediumController@edit')->name('editMediums');
    Route::post('addMedium','MediumController@add')->name('addMedium');
    Route::post('editMedium','MediumController@Update')->name('editMedium');
    Route::post('deleteMedium','MediumController@delete')->name('deleteMedium');
    
    

    
    
});